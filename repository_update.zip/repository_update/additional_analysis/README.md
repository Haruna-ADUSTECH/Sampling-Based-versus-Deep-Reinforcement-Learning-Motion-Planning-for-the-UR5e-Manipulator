# Additional analysis

These files back the statistical tests of Section 6.3, the gripper-aware correction and benchmark rerun of Sections 7.1 and 7.2, and the simulation checks of Section 7.7 of the paper. The hardware logs and the deployed policies are in `hardware/` (see `hardware/README_HARDWARE.md`). Commands are run from the repository root, except where a folder says otherwise.

## gripper_aware_rerun/

The full benchmark rerun under the gripper-aware collision model (Table 4 of the paper). Run everything from inside this folder, because the paths are relative.

- `env.py`: the gripper-aware model. It is the same file as `hardware/env.py`. The original capsule model is extended by a sphere of 0.295 m (0.26 m reach plus 0.035 m half-width) around the wrist centre. The wrist centre must stay at least 0.35 m above the base plane (the 0.055 m ground allowance plus the 0.295 m reach), and the sphere must stay clear of the shoulder column, the upper arm and every bar.
- `agents.py`, `planners.py`, `train.py`, `evaluate.py`: the original code of the repository root, unchanged. Only `env.py` differs.
- `train.py` retrains one agent, for example `python3 train.py td3 s1 3000 0`. `run_all_training.sh` retrains all six policies (TD3 and SAC, scenes S1 to S3, 3000 episodes, seed 0).
- `evaluate.py` generates 50 queries per scene with the gripper-aware check enforced during sampling. These are the 150 queries of `hardware/queries.json`. It rebuilds PRM, PRM+SC and RRT-Connect with the parameters and seeds of the original benchmark, evaluates the retrained actors in `models/`, and writes `results.json`, `summary.json`, `fig_scenes.pdf` and `fig_box.pdf`.
- `results.json` holds the per-trial records (R in rad^2). In `summary.json` and in the table rows printed by `evaluate.py`, R is multiplied by 100. The paper reports R from `results.json` in units of 10^-5 rad^2.
- `logs/` and `models/` hold the training and evaluation logs and the retrained weights.

These retrained policies were not used on the robot. The policies on the robot are the original ones in `hardware/models/`.

## original_model_rerun_same_machine/

`results.json`, `summary.json` and `logs/evaluate.log` from running the unchanged, original `evaluate.py` of the repository root on the computer that produced the rerun above. Success rates, path lengths, roughness values, execution times and paired tests equal those of Table 3. Only the planning times differ, and they give the baseline for the timing comparison in Section 7.2 (the two runs were made on different computers than Table 3).

## analysis_scripts/

Each script prints its usage when it is started without arguments or with the wrong ones.

- `check_original_queries.py env.py hardware/env.py` regenerates the 150 original frozen queries with the original `env.py` and counts how many have an invalid start or goal under the gripper-aware model: 120 of 150 (80%), which is 41 of 50 on S1, 39 on S2 and 40 on S3 (Section 7.1).
- `verify_queries_json.py <env.py> <queries.json>` checks that the seeded generator reproduces a stored query file. It does so exactly (difference 0) for `hardware/queries_original_bare_arm.json` with the original `env.py` and for `hardware/queries.json` with `hardware/env.py`.
- `bootstrap_sac_vs_prmsc.py results.json` gives paired bootstrap intervals and Wilcoxon tests of SAC+HER against PRM+SC on the original benchmark (Section 6.3).
- `summarize_rerun.py <results.json>` prints one benchmark run as a table with R in 10^-5 rad^2, Wilson intervals for the success rates, paired Wilcoxon tests and paired bootstrap intervals (10,000 resamples, seed 0, ratio of means) against PRM+SC, and the success rate per scene.
- `eval_policy_gate.py hardware <models folder> env.py <out.csv>` runs a set of TD3+HER and SAC+HER policies in closed loop on the 150 hardware queries, once with the bare-arm model and once with the gripper-aware model behind the run-time check of `hw_run_policy.py` (a refused target is not executed, the state is held, and the policy is queried again). It uses `ptload.py`, so PyTorch is not needed.

## analysis_results/

Outputs of the scripts above, so that the numbers can be read without running anything.

| File | Paper |
|---|---|
| `check_original_queries.txt` | Section 7.1: 120 of 150 queries invalid under the gripper-aware model |
| `verify_queries_json.txt` | Both stored query sets are reproduced exactly |
| `bootstrap_sac_vs_prmsc_original.txt` | Section 6.3: SAC+HER against PRM+SC, L +0.89% (n=148) and R +111% |
| `summary_original_benchmark.txt` | Table 3 and the paired tests of Section 6.3 |
| `summary_original_model_rerun_same_machine.txt` | Same results on the second computer, with its own timings |
| `summary_gripper_aware_rerun.txt` | Table 4 |
| `policy_gate_deployed.csv`, `_stdout.txt` | Section 7.7: deployed policies on the 150 queries, 99.3% (SAC+HER) and 98.0% (TD3+HER) under the bare-arm model, 80.7% and 72.0% behind the run-time check |
| `policy_gate_retrained.csv`, `_stdout.txt` | Section 7.7: retrained policies behind the same check, 94.7% (SAC+HER) and 85.3% (TD3+HER) |

The retrained policies reach 94.0% (SAC+HER) and 85.3% (TD3+HER) in `summary_gripper_aware_rerun.txt`. The benchmark protocol of `evaluate.py` stops stalled rollouts early and counts one SAC+HER query fewer than `eval_policy_gate.py`, which applies the 120-step rule of the robot loop to every query.

## Requirements

Python 3 with numpy, scipy, pandas and matplotlib. PyTorch is needed only to retrain policies or to run `evaluate.py`.
