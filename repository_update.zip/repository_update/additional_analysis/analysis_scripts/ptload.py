"""Minimal, whitelist-only loader for torch state_dict .pt files (zip + pickle),
returning numpy arrays. Avoids installing torch and avoids unpickling arbitrary objects."""
import collections, io, pickle, zipfile
import numpy as np

_DT = {'FloatStorage': np.float32, 'DoubleStorage': np.float64, 'HalfStorage': np.float16,
       'LongStorage': np.int64, 'IntStorage': np.int32}

def load_pt(path):
    z = zipfile.ZipFile(path)
    pkl = [n for n in z.namelist() if n.endswith('data.pkl')][0]
    prefix = pkl[:-len('data.pkl')]

    def rebuild(storage, offset, size, stride, requires_grad=False, hooks=None, metadata=None):
        size = tuple(size); stride = tuple(stride)
        itemsize = storage.itemsize
        return np.lib.stride_tricks.as_strided(
            storage[offset:], shape=size, strides=tuple(s * itemsize for s in stride)).copy()

    class U(pickle.Unpickler):
        def find_class(self, module, name):
            if module == 'torch._utils' and name == '_rebuild_tensor_v2':
                return rebuild
            if module == 'torch' and name in _DT:
                return name
            if module == 'collections' and name == 'OrderedDict':
                return collections.OrderedDict
            raise pickle.UnpicklingError(f'blocked {module}.{name}')
        def persistent_load(self, pid):
            typ, storage_type, key, location, numel = pid
            assert typ == 'storage'
            return np.frombuffer(z.read(f'{prefix}data/{key}'), dtype=_DT[storage_type])

    return U(io.BytesIO(z.read(pkl))).load()

class Actor:
    """TD3: Linear-ReLU-Linear-ReLU-Linear-Tanh (3 outputs). SAC: same trunk, 6 outputs; deterministic action = tanh(mu)."""
    def __init__(self, path, algo):
        sd = load_pt(path)
        self.W = [sd[f'{i}.weight'].astype(np.float64) for i in (0, 2, 4)]
        self.b = [sd[f'{i}.bias'].astype(np.float64) for i in (0, 2, 4)]
        self.algo = algo
    def __call__(self, q3, g3):
        x = np.concatenate([q3, g3])
        h = np.maximum(self.W[0] @ x + self.b[0], 0)
        h = np.maximum(self.W[1] @ h + self.b[1], 0)
        o = self.W[2] @ h + self.b[2]
        if self.algo == 'td3':
            return np.tanh(o)
        return np.tanh(o[:3])
