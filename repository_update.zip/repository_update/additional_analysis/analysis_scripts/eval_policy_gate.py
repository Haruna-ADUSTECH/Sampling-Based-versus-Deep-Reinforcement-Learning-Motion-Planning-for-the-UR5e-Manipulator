"""Closed-loop success of a set of TD3+HER / SAC+HER actors on the 50 hardware queries per scene, under the
bare-arm collision model and under the gripper-aware (hardware) model, using the same rule as the hardware loop in
hw_run_policy.py: target = clip(q + 0.25 * a); if the target is flagged by the collision model the state is held;
success when ||q - goal|| <= 0.15 rad; step budget 120.

usage (from the repository root), deployed policies:
    python3 additional_analysis/analysis_scripts/eval_policy_gate.py hardware hardware/models env.py additional_analysis/analysis_results/policy_gate_deployed.csv
retrained policies of the gripper-aware rerun:
    python3 additional_analysis/analysis_scripts/eval_policy_gate.py hardware additional_analysis/gripper_aware_rerun/models env.py additional_analysis/analysis_results/policy_gate_retrained.csv

  hardware_dir : folder with env.py (gripper-aware model) and queries.json
  models_dir   : folder with td3_s1.pt ... sac_s3.pt
  bare_env.py  : the original bare-arm env.py of the simulation study
The numpy-only loader in ptload.py is used, so torch is not needed.
"""
import csv, importlib.util, json, os, sys
import numpy as np
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from ptload import Actor

hw, models, bare_env, out = sys.argv[1:5]
def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path); m = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(m); return m
A = load('envA', bare_env); H = load('envH', os.path.join(hw, 'env.py'))
queries = json.load(open(os.path.join(hw, 'queries.json')))
ALPHA, TOL, CAP = 0.25, 0.15, 120

def rollout(actor, scene, qs, qg):
    q = np.array(qs, float); rej = 0
    for t in range(1, CAP + 1):
        tgt = np.clip(q + ALPHA * actor(q, qg), H.QLIM[:, 0], H.QLIM[:, 1])
        if scene.in_collision(tgt[None])[0]:
            rej += 1
        else:
            q = tgt
        if np.linalg.norm(q - qg) <= TOL:
            return True, t, rej
    return False, CAP, rej

rows, tot = [], {}
for scene in ('s1', 's2', 's3'):
    bars = [tuple(b) for b in H.SCENES[scene].bars]
    for algo in ('sac', 'td3'):
        act = Actor(os.path.join(models, f'{algo}_{scene}.pt'), algo)
        for tag, env in (('bare', A.Scene(bars)), ('gripper_aware', H.Scene(bars))):
            n_ok = 0
            for q in queries[scene]:
                ok, steps, rej = rollout(act, env, q['q_start'], q['q_goal'])
                n_ok += ok
                rows.append(dict(scene=scene, policy=algo, model=tag, query=q['query_idx'], success=int(ok), steps=steps, rejections=rej))
            tot[(algo, tag)] = tot.get((algo, tag), 0) + n_ok
            print(f'{scene} {algo} {tag:14s} {n_ok}/50')
with open(out, 'w', newline='') as fh:
    w = csv.DictWriter(fh, fieldnames=list(rows[0])); w.writeheader(); w.writerows(rows)
for k, v in sorted(tot.items()):
    print(f'TOTAL {k[0]} {k[1]:14s} {v}/150 = {100*v/150:.1f}%')
