"""Re-check the 150 ORIGINAL frozen queries against the gripper-aware (hardware) collision model.

Regenerates the exact 150 frozen queries (50 per scene) of the original
benchmark with the original, bare-arm env.py (same seeded procedure as the
original evaluate.py: default_rng(42) shared across scenes, sample_free, and
rejection of pairs closer than 1.2 rad). It then counts how many start or goal
configurations are invalid under the gripper-aware env.py that was used on the
robot (hardware/env.py).

Usage (from the repository root):
    python3 additional_analysis/analysis_scripts/check_original_queries.py env.py hardware/env.py

Reported in the paper (Section 7.1): 120 of 150 queries (80%) have an invalid
start or goal under the gripper-aware model (82% on S1, 78% on S2, 80% on S3).
"""
import importlib.util
import sys

import numpy as np


def load(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


if len(sys.argv) != 3:
    sys.exit(__doc__)
OLD = load(sys.argv[1], "old_env")
NEW = load(sys.argv[2], "new_env")

N_QUERIES = 50
rng = np.random.default_rng(42)
scene_queries = {}
for scene_name, scene in OLD.SCENES.items():
    queries = []
    while len(queries) < N_QUERIES:
        qs, qg = scene.sample_free(rng, 2)
        if np.linalg.norm(qs - qg) > 1.2:
            queries.append((qs, qg))
    scene_queries[scene_name] = queries

total_bad_queries = 0
for scene_name, queries in scene_queries.items():
    qs_arr = np.array([q[0] for q in queries])
    qg_arr = np.array([q[1] for q in queries])
    bad = NEW.SCENES[scene_name].in_collision(np.vstack([qs_arr, qg_arr]))
    bad_queries = (bad[:N_QUERIES] | bad[N_QUERIES:]).sum()
    total_bad_queries += bad_queries
    print(f"scene {scene_name}: {bad_queries}/{N_QUERIES} queries have an "
          f"invalid start or goal ({100 * bad_queries / N_QUERIES:.0f}%)")
print(f"TOTAL: {total_bad_queries}/{3 * N_QUERIES} queries "
      f"({100 * total_bad_queries / (3 * N_QUERIES):.0f}%)")
