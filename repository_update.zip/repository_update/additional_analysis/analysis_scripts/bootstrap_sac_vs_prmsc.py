"""Paired bootstrap confidence intervals and Wilcoxon tests, SAC+HER vs PRM+SC.

Uses the per-trial records in results.json of the ORIGINAL benchmark. For path
length (L) and roughness (R) it reports the ratio-of-means percentage
difference (the same estimator that evaluate.py prints), a 95% percentile
bootstrap interval (10,000 paired resamples, seed 0), and the two-sided paired
Wilcoxon signed-rank test, over queries solved by both methods.

Usage:
    python3 bootstrap_sac_vs_prmsc.py <path/to/results.json>

Reported in the paper (Section 6.3): L +0.9% (95% CI +0.4 to +1.5%, n=148,
W=3998, p=0.004); R +111% (95% CI +40 to +312%, n=148, W=1330, p=1.2e-15).
"""
import json
import sys

import numpy as np
import pandas as pd
from scipy.stats import wilcoxon

if len(sys.argv) != 2:
    sys.exit(__doc__)

rng = np.random.default_rng(0)
results = json.load(open(sys.argv[1]))["results"]
dfs = {m: pd.DataFrame(results[m]) for m in results}


def paired(b_name, m_name, col):
    b = dfs[b_name].set_index(["scene", "query"])
    x = dfs[m_name].set_index(["scene", "query"])
    j = b.join(x, lsuffix="_b", rsuffix="_m")
    j = j[(j.success_b) & (j.success_m)].dropna(subset=[f"{col}_b", f"{col}_m"])
    return j[f"{col}_b"].values, j[f"{col}_m"].values


def ratio_of_means_pct(b, m):
    return 100 * (m.mean() - b.mean()) / b.mean()


for metric in ["L", "R"]:
    bvals, mvals = paired("prm_sc", "sac", metric)
    n = len(bvals)
    point = ratio_of_means_pct(bvals, mvals)
    idx = np.arange(n)
    boots = np.empty(10000)
    for i in range(10000):
        s = rng.choice(idx, size=n, replace=True)
        boots[i] = ratio_of_means_pct(bvals[s], mvals[s])
    lo, hi = np.percentile(boots, [2.5, 97.5])
    W, p = wilcoxon(bvals, mvals)
    print(f"{metric}: n={n}  ratio-of-means diff = {point:+.2f}%  "
          f"95% bootstrap CI [{lo:+.2f}%, {hi:+.2f}%]  Wilcoxon W={W:.0f} p={p:.4g}")
