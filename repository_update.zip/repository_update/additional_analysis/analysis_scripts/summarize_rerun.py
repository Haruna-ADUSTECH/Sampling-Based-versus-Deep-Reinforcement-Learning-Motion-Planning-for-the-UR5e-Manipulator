"""Summary numbers for one benchmark run (original model or hardware-model rerun).

Reads results.json written by evaluate.py and prints: the pooled table rows with R in units of 1e-5 rad^2
(the unit used in the manuscript), Wilson 95% intervals for the success rates, paired Wilcoxon tests and paired
bootstrap intervals (10,000 resamples, seed 0, ratio-of-means estimator) against PRM+SC, and per-scene success.

usage (from the repository root):
    python3 additional_analysis/analysis_scripts/summarize_rerun.py additional_analysis/gripper_aware_rerun/results.json
"""
import json, sys
import numpy as np, pandas as pd
from scipy.stats import wilcoxon

METHODS = ['prm', 'prm_sc', 'rrt', 'td3', 'sac']
LAB = dict(prm='PRM', prm_sc='PRM+SC', rrt='RRT-Connect', td3='TD3+HER', sac='SAC+HER')
res = json.load(open(sys.argv[1]))['results']
dfs = {m: pd.DataFrame(res[m]) for m in METHODS}

def wilson(k, n, z=1.96):
    p = k / n; d = 1 + z * z / n
    c = (p + z * z / (2 * n)) / d; h = z * np.sqrt(p * (1 - p) / n + z * z / (4 * n * n)) / d
    return 100 * (c - h), 100 * (c + h)

print('method        succ%   [Wilson]        L mean+-sd     R(1e-5) mean+-sd   t_plan[ms]  t_exec[s] mean+-sd   (n solved)')
for m in METHODS:
    d = dfs[m]; ok = d[d.success]
    lo, hi = wilson(len(ok), len(d))
    print(f"{LAB[m]:12s} {100*len(ok)/len(d):6.1f}  [{lo:4.1f},{hi:5.1f}]  {ok.L.mean():.2f} +- {ok.L.std():.2f}   "
          f"{1e5*ok.R.mean():5.1f} +- {1e5*ok.R.std():5.1f}      {ok.t_plan.mean():6.1f}      {ok.t_exec.mean():.2f} +- {ok.t_exec.std():.2f}   ({len(ok)})")
print('\nper scene success %:')
for s in ['s1', 's2', 's3']:
    print(s, '  '.join(f"{LAB[m]} {100*dfs[m][dfs[m].scene==s].success.mean():.0f}" for m in METHODS))

def paired(a, b, col):
    A = dfs[a].set_index(['scene', 'query']); B = dfs[b].set_index(['scene', 'query'])
    j = A.join(B, lsuffix='_a', rsuffix='_b'); j = j[(j.success_a) & (j.success_b)].dropna(subset=[f'{col}_a', f'{col}_b'])
    return j[f'{col}_a'].values, j[f'{col}_b'].values

rng = np.random.default_rng(0)
print('\npaired vs PRM+SC (ratio of means, 95% bootstrap CI, Wilcoxon):')
for m in ['prm', 'rrt', 'td3', 'sac']:
    for col in ['L', 'R']:
        b, x = paired('prm_sc', m, col); n = len(b)
        pt = 100 * (x.mean() - b.mean()) / b.mean(); idx = np.arange(n)
        boots = np.array([100 * (x[s].mean() - b[s].mean()) / b[s].mean() for s in (rng.choice(idx, n, replace=True) for _ in range(10000))])
        lo, hi = np.percentile(boots, [2.5, 97.5]); W, p = wilcoxon(b, x)
        print(f"  {LAB[m]:12s} {col}: n={n:3d}  {pt:+7.2f}%  CI [{lo:+7.2f}, {hi:+7.2f}]  W={W:.0f}  p={p:.3g}")
b, x = paired('prm', 'sac', 'L'); print(f"  SAC+HER vs raw PRM, L: n={len(b)}  {100*(x.mean()-b.mean())/b.mean():+.2f}%")
