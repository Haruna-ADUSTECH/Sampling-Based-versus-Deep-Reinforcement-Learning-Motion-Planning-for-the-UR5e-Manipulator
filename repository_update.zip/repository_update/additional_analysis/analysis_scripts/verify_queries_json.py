"""Check that the seeded query generator reproduces a stored query file.

Regenerates 150 queries (50 per scene) with the given env.py (default_rng(42)
shared across scenes, sample_free, rejection of pairs closer than 1.2 rad) and
compares them with the start/goal configurations stored in a queries file.

Usage (from the repository root):
    # the original queries, bare-arm model
    python3 additional_analysis/analysis_scripts/verify_queries_json.py env.py hardware/queries_original_bare_arm.json
    # the queries used on the robot, gripper-aware model
    python3 additional_analysis/analysis_scripts/verify_queries_json.py hardware/env.py hardware/queries.json

Both comparisons print a maximum absolute difference of 0.00e+00 for every scene.
"""
import importlib.util
import json
import sys

import numpy as np

if len(sys.argv) != 3:
    sys.exit(__doc__)

spec = importlib.util.spec_from_file_location("gen_env", sys.argv[1])
ENV = importlib.util.module_from_spec(spec)
spec.loader.exec_module(ENV)

N_QUERIES = 50
rng = np.random.default_rng(42)
scene_queries = {}
for scene_name, scene in ENV.SCENES.items():
    queries = []
    while len(queries) < N_QUERIES:
        qs, qg = scene.sample_free(rng, 2)
        if np.linalg.norm(qs - qg) > 1.2:
            queries.append((qs, qg))
    scene_queries[scene_name] = queries

stored = json.load(open(sys.argv[2]))
for scene_name in ["s1", "s2", "s3"]:
    max_err = 0.0
    for i in range(N_QUERIES):
        qs_stored = np.array(stored[scene_name][i]["q_start"])
        qg_stored = np.array(stored[scene_name][i]["q_goal"])
        qs_new, qg_new = scene_queries[scene_name][i]
        max_err = max(max_err, np.max(np.abs(qs_stored - qs_new)),
                      np.max(np.abs(qg_stored - qg_new)))
    print(f"{scene_name}: max abs difference to stored queries = {max_err:.2e}")
