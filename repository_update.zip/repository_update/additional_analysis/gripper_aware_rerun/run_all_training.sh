#!/bin/bash
# retrain the six policies under the hardware collision model (single seed 0, 3000 episodes each), two at a time
cd "$(dirname "$0")"
printf "td3 s1\nsac s1\ntd3 s2\nsac s2\ntd3 s3\nsac s3\n" | xargs -P 2 -L 1 bash -c 'python3 train.py $0 $1 3000 0 > logs/train_$0_$1.log 2>&1'
echo ALL_DONE > logs/ALL_DONE
