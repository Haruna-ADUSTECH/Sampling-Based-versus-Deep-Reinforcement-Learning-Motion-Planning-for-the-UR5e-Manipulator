# Hardware validation on a UR5e

This folder holds what lies behind Section 7 of the paper: the scripts that drove the robot, the raw logs, the policies that were deployed, and the code that turns the logs into the numbers and figures of the paper. Commands below are run from the repository root.

The robot was a UR5e with an OnRobot RG6 gripper, controlled over RTDE (ur_rtde 1.6.3, Python 3.10, controller at 192.168.1.10). Only joints 1 to 3 move. Joints 4 to 6 stay at the fixed pose (-1.5982, -1.5368, 0.0778) rad. In the logs they stay within 0.0004 rad of it in every sampling-based trial and within 0.05 rad in the learned-policy trials.

## 1. What is in this folder

| Path | What it is |
|---|---|
| `hw_config.py` | Settings used on the robot: controller address, joint limits, fixed wrist pose, moveJ speed and acceleration, servoJ parameters, obstacle positions |
| `hw_common.py`, `hw_run_sampling.py`, `hw_run_policy.py` | The scripts that drive the robot (shared helpers, sampling-based planners, learned policies). See Section 4 for the version history |
| `env.py`, `planners.py` | The gripper-aware collision model and the planners used on the robot. The planners are the ones of the simulation study |
| `queries.json` | The 150 queries (50 per scene) used on the robot. They were generated under the gripper-aware model, so every start and goal is valid for the gripper-equipped arm |
| `queries_original_bare_arm.json` | The 150 original queries of the simulation study (bare-arm model). 120 of them have an invalid start or goal under the gripper-aware model (Section 7.1 of the paper) |
| `models/` | The six learned policies that were deployed. They are the original policies of the simulation study, trained against the bare-arm model, and they are identical to `models/` in the repository root. They were not retrained for the robot |
| `hw_logs/<scene>/<method>/` | The raw logs. `q<i>.csv` has the 50 Hz joint positions (`t, q1..q6`) of the last run of query `i`. `meta.csv` has one row per run: `query_idx, success, t_plan_ms, t_exec_s, protective_stop` |
| `make_tables.py`, `clean_meta.py` | The table script that reads `hw_logs` (it pools the three scenes and reads every row of every `meta.csv`, see the note at the start of Section 5), and the helper that was used once on the S1 PRM+SC log (Section 5.1) |
| `analysis/` | The scripts and outputs behind the numbers of Section 7 (Section 3) |
| `smoke_test.py`, `tiny_motion_test.py`, `check_fk.py`, `check_fk_live.py`, `validate_kinematics.py`, `kinematic_validation_report.txt`, `mock_rtde/` | Checks written before the trials. `mock_rtde/` is a toy stand-in used for dry runs of the control flow. It is not a model of the real controller |
| `../CHECKSUMS.sha256` | In the repository root. SHA-256 of every file in `hardware/` and `additional_analysis/`. Check with `sha256sum -c CHECKSUMS.sha256` |

## 2. What was run

| Scene | Method | Reported trials | Queries (positions in `queries.json`) | Log folder |
|---|---|---|---|---|
| S1 | PRM, PRM+SC, RRT-Connect | 5 each | 0, 1, 2, 3, 4 | `hw_logs/s1/prm`, `prm_sc`, `rrt_connect` |
| S2 | PRM, PRM+SC, RRT-Connect | 5 each | 0, 1, 45, 3, 20 | `hw_logs/s2/...` |
| S3 | PRM, PRM+SC, RRT-Connect | 5 each | 2, 47, 10, 20, 40 | `hw_logs/s3/...` |
| S1 | SAC+HER | 10 | 0 to 9 | `hw_logs/s1/sac_her` |
| S1 | TD3+HER | 9 | 0, 2 to 9 | `hw_logs/s1/td3_her` |
| S3 | SAC+HER | 10 | 0 to 9 | `hw_logs/s3/sac_her` |
| S3 | TD3+HER | 8 | 1 to 5, 7 to 9 | `hw_logs/s3/td3_her` |
| S2 | SAC+HER | none reported | 0 to 9 attempted | `hw_logs/s2/sac_her` |

The S2 learned-policy attempts ended in a persistent fault of the control connection and are not part of any result (Section 5.4).

Obstacle positions (metres, x and y from the robot base, as in `hw_config.py`): S1 (0.45, 0.10); S2 (0.42, -0.30) and (0.42, 0.30); S3 (0.30, -0.38), (0.50, 0.00) and (0.30, 0.38). The sampling-based planners were executed with one `moveJ` per path segment at 0.30 rad/s and 0.60 rad/s^2. The learned policies ran in a closed loop with `servoJ` (time 0.1 s, lookahead 0.1 s, gain 300), one policy step per 0.1 s, a budget of 120 steps and a goal tolerance of 0.15 rad. Joint positions were logged at 50 Hz in every trial.

## 3. Reproducing the numbers

All commands need numpy, pandas and scipy. `matplotlib` is needed for the figures only. PyTorch is not needed: `analysis/ptload.py` reads the `.pt` files with numpy and refuses anything that is not a plain tensor.

| Where in the paper | Command (from the repository root) | Output in `hardware/analysis/out/` |
|---|---|---|
| Tables 6 to 8 (sampling-based trials, S1, S2, S3) | `python3 hardware/analysis/verify_sampling_tables.py .` | `sampling_tables.txt` |
| Table 5 and Fig. 9 (S1 PRM+SC, 13 successful runs) | rows 7 to 19 of `hw_logs/s1/prm_sc/meta_RAW_BACKUP.csv`; segment counts from `replan_check.csv` | |
| Supporting check, not a table of the paper: the logged paths follow the planned ones | `python3 hardware/analysis/replan_check.py . hardware/analysis/out/replan_check.csv` | `replan_check.csv`, `replan_check_stdout.txt` |
| Link-to-bar clearance, 0.058 m on S2 and 0.084 m on S3 | `python3 hardware/analysis/clearance_paths.py hardware hardware/analysis/out/clearance_paths.csv` | `clearance_paths.csv` |
| The six early S1 failures (Section 7.1) | `python3 hardware/analysis/forensic_early_failures.py . hardware/queries_original_bare_arm.json` | `forensic_early_failures.txt` |
| Table 9, Fig. 14 and the numbers of Section 7.7 | `python3 hardware/analysis/rl_hw_analysis.py hardware hardware/analysis/out env.py` | `rl_hw_summary.json`, `rl_hw_trials.csv`, `rl_hw_attempts.csv`, `rl_hw_path_fidelity.csv` |
| The arm standing still in the S2 fault | `python3 hardware/analysis/s2_arm_motion.py hardware hardware/analysis/out/s2_arm_motion.csv` | `s2_arm_motion.csv` |
| Supporting check: same moveJ speed in all scenes | `python3 hardware/analysis/sampling_peak_speed.py hardware hardware/analysis/out/sampling_peak_speed.csv` | `sampling_peak_speed.csv` |
| Per-query summary of the terminal output of the learned-policy runs | `python3 hardware/analysis/summarize_captures.py <out.csv> <capture files>` | `terminal_run_summary.csv` (host names and paths removed; the capture files themselves are not released) |
| Figures 9 and 14 | `python3 hardware/analysis/make_hw_figures.py <output folder>` | `Fig9.pdf`, `Fig14.pdf` (numbers are typed in the script and can be checked against the files above) |

Two notes on units. In the hardware tables, roughness `R` is computed from the 50 Hz log and multiplied by 100, so its unit is 10^-2 rad^2 s^-4. The simulated `R` of Tables 3 and 4 is computed on resampled waypoints and is reported in 10^-5 rad^2. The two are not comparable in absolute size, only in ordering. Also, `rl_hw_analysis.py` needs the original `env.py` from the repository root as its third argument to fill the bare-arm column of the 50-query simulations.

## 4. Which script version recorded which log

The scripts and logs carry modification times (from the author's computer, as stored in the archive this folder was built from). Read together they give this order:

| Date and time | Event |
|---|---|
| 29 Jul 11:36 to 11:40 | `README_HARDWARE.md`, `hw_common.py`, `make_tables.py`, `planners.py`, `models/` written |
| 30 Jul 06:23 | gripper-aware `env.py` and the regenerated `queries.json` |
| 30 Jul 07:13 to 07:28 | S1 sampling-based runs; `clean_meta.py` applied to the PRM+SC log at 07:27 |
| 30 Jul 12:39 | last edit of `hw_run_sampling.py` |
| 30 Jul 12:42 to 13:52 | S2 sampling-based runs |
| 31 Jul 06:57 to 07:10 | S3 sampling-based runs |
| 31 Jul 08:26 | last edit of `hw_config.py` |
| 31 Jul 09:57 to 10:26 | S1 and S3 learned-policy runs |
| 31 Jul 11:01 | last edit of `hw_run_policy.py` |
| 31 Jul 11:10 | last S2 learned-policy log |

What this means for each script:

1. **`hw_run_sampling.py`.** The S1 sampling-based runs are older than the last edit of this file, and the earlier version is not available. The logs agree with the released script: the peak joint speed is 0.30 rad/s in all 45 trials of all three scenes (`sampling_peak_speed.csv`), and replanning offline with the released planners and seeds reproduces every logged path to within 0.07% in length and every start and end point to within 0.0004 rad (`replan_check.csv`). The S1 tables therefore follow the same procedure as S2 and S3, but the older file itself cannot be inspected.
2. **`hw_config.py`.** It was last edited after all sampling-based runs and before the learned-policy runs. The moveJ values in the released file (0.30 rad/s, 0.60 rad/s^2) match the logs of every sampling-based run, as stated above. The wrist pose (from the logs) and the servoJ parameters (from the terminal output of the learned-policy runs) also agree with the released file, so its values are the ones that were in force for the trials as far as the records allow checking.
3. **`hw_run_policy.py`.** It was last edited after all S1 and S3 learned-policy runs. The released file ends every servoJ segment with `stopJ(2.0)`. According to Section 7.7 of the paper, the S1 and S3 trials were recorded with the version that called `servoStop()` instead, and `stopJ` came later, while the S2 fault was being investigated. That older version is not available, so this statement rests on the modification times and on the logs, not on the file. The released file differs from the file in the archive in one comment block only: the original comment gave a shoulder singularity as the confirmed cause of the S2 fault, which the paper withdraws. The code lines are unchanged. SHA-256 of the file as received: `07a542c77e38e08820071e76e178ad635b463e442a039713d7631ecc35d57c31`.
4. **S2 learned-policy attempts.** They span both versions of the script. Only `meta.csv` keeps all attempts (60 rows). The 50 Hz log of a query is overwritten when the query is run again, so the files `q3.csv` to `q9.csv` belong to the last runs only.

## 5. How the reported trials were selected from the raw logs

`meta.csv` has no run labels, no time stamps and no script version, so the selection below was reconstructed from the order of the rows, the times of execution, the terminal output where it exists (`analysis/out/terminal_run_summary.csv`) and the description in the paper. Please check it against your own notes.

`make_tables.py` pools the three scenes and reads every row of every `meta.csv`. For PRM, PRM+SC and RRT-Connect every row is a reported trial, so its table is the pooled version of Tables 6 to 8 (15 trials per method). For SAC+HER and TD3+HER it also reads the development attempts and the S2 attempts, so its lines for the learned policies are not the numbers of the paper. Use `analysis/rl_hw_analysis.py` for those.

**5.1 Sampling-based trials.** Every `meta.csv` has one row per query, except `hw_logs/s1/prm_sc/meta.csv`. Its raw version is `meta_RAW_BACKUP.csv` with 19 rows: six failed attempts of query 0 (rows 1 to 6), then 13 successful runs (rows 7 to 19). `clean_meta.py` kept the last row of every query, which gives the five rows of `meta.csv` that enter Table 6. All 13 successful runs are shown in Table 5 and Fig. 9 of the paper. The six failures belong to the time before the collision model was corrected. Four of them stopped 2.152 to 2.153 s after the start of the motion. `forensic_early_failures.txt` replans the original query 0 of S1 and finds one segment that the gripper-aware model flags from 0.21 rad of leading-joint travel on, which is consistent with a contact, but the log does not store which query was run, so this is a consistency check and not a proof.

**5.2 S1, SAC+HER (`hw_logs/s1/sac_her/meta.csv`, 26 rows, 10 reported).**

| Rows | Queries | What they are | Reported |
|---|---|---|---|
| 1, 2 | 0 | The 120 steps ran in 1.25 s, because the loop was not yet paced to the 0.1 s servoJ period (a comment in the script describes a loop about ten times too fast) | no |
| 3, 4 | 0 | Successful runs before the `servoStop` fix; row 4 appears in the terminal output | no |
| 5 to 8 | 1 to 4 | Failures at step 1 with the controller's limit check, after row 4, before the `servoStop` fix | no |
| 9, 10 | 0, 1 | Final settings | yes |
| 11 to 13 | 0, 1, 2 | Test with servoJ time 0.5 s instead of 0.1 s (rows 12 and 13 appear in the terminal output) | no |
| 14 to 16 | 2, 3, 4 | Final settings | yes |
| 17 to 21 | 5 to 9 | Final settings, first pass | no |
| 22 to 26 | 5 to 9 | Final settings, second pass, same outcomes as the first | yes |

Each query is counted once. The second pass was taken for queries 5 to 9 because the surviving 50 Hz files belong to it. The outcomes of both passes are the same, so the count of 6 successes in 10 does not depend on the choice. For queries 0 and 1 the surviving 50 Hz files come from the 0.5 s test, so these two trials are left out of the tracking and path-fidelity analyses.

**5.3 The other learned-policy logs.** All rows of `s1/td3_her` (9), `s3/sac_her` (10) and `s3/td3_her` (8) are reported. Each has one row per query. TD3+HER was not run on S1 query 1 and on S3 queries 0 and 6.

**5.4 Scene S2 (`hw_logs/s2/sac_her/meta.csv`, 60 rows, none reported).** The first three queries ran correctly in several runs. In the terminal output of two full runs, every query after them failed at its first step with the controller's limit check. Several later runs are partial, and in all of them the queries from 3 on failed with the budget used up. In the last runs of queries 3 to 9, whose 50 Hz logs survive, the arm stood still at the start configuration of query 3 for all seven queries (`s2_arm_motion.csv`: the largest excursion of any joint is 0.0003 rad, and the first logged position is 1.6 to 4.1 rad away from the start of queries 4 to 9). In the terminal output of the first of these runs the first target was refused at step 1 by the run-time check in six of the seven queries and by the controller's limit check in the seventh. The gated simulation solves queries 4 to 8 without any refusal. The fault is reported in the paper as an open problem without a confirmed cause.

## 6. What this record does not contain

- The commanded servoJ targets were not logged. The tracking analysis reconstructs them by evaluating the deployed policy on the logged joint state at the start of each 0.1 s step.
- A `q<i>.csv` file is overwritten when query `i` is run again. Only `meta.csv` keeps every attempt.
- Terminal output was captured for most runs but not for all, and it is not released in full. `terminal_run_summary.csv` has one line per query of the captured runs.
- The record comes from one robot in one cell. The physical obstacle positions were located with the robot's live tool-position readout, not with an external measurement, and the clearance values are model-based.

## 7. Running the scripts on a robot

The scripts moved a real robot for the results in the paper, but they are research code. Read them and `hw_config.py` before you use them, test on URSim first, and keep a person at the teach pendant with a hand on the emergency stop. Never run them unattended.

1. Install ur_rtde (`pip install ur_rtde`) and set `ROBOT_IP` in `hw_config.py`.
2. Place the cylindrical obstacles (radius about 0.05 m, height about 0.9 m) at the positions listed in Section 2. If your cell is different, edit `SCENE_BARS_XY`. That is then a different scene from the paper, the sampling-based planners replan for it automatically, and the learned policies, which were trained for the original layout, should be retrained first.
3. Start with a small number of queries and with the conservative moveJ values of `hw_config.py`:

```
python3 hw_run_sampling.py prm     s1 5
python3 hw_run_sampling.py prm_sc  s1 5
python3 hw_run_sampling.py rrt     s1 5
python3 hw_run_policy.py   sac     s1 10
python3 hw_run_policy.py   td3     s1 0,2,3,4,5,6,7,8,9
python3 make_tables.py hw_logs
```

Read the note at the start of Section 5 before you use the last command on the released logs.

The learned-policy script checks every target against the gripper-aware model before it is sent. A refused target is not executed. The arm holds its position for that step and the policy is queried again from the measured state. This is the run-time check ("gate") described in Section 7.7 of the paper.

Several docstrings in the scripts were written before the trials and still say that the code had not been run on a real controller. That sentence is out of date for this record and is kept only because the files are otherwise unchanged.
