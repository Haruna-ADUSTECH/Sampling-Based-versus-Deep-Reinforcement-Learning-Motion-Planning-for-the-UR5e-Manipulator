"""Run this SECOND, after smoke_test.py passes cleanly.

Moves joint 3 (elbow) by +0.10 rad (~5.7 degrees) and back to its
starting position, at very low speed. This is deliberately the
smallest, most obviously-safe motion that still proves moveJ() and the
safety-limit checks work end to end, before running the full protocol.

Watch the URSim 3D view (or the real robot, if you've already validated
on URSim first) the entire time this runs.

Usage:
    python3 tiny_motion_test.py
"""
import time

import hw_config as cfg
from hw_common import connect, full_q, validate_target

SPEED = 0.05    # rad/s -- deliberately far below MOVEJ_SPEED_INIT
ACCEL = 0.10    # rad/s^2

rtde_c, rtde_r = connect()  # will prompt for an explicit y/N confirmation

try:
    q0 = rtde_r.getActualQ()[:3]
    print(f"Starting position (joints 1-3): {q0}")

    q_there = list(q0)
    q_there[2] += 0.10  # nudge the elbow only
    delta = [round(b - a, 4) for a, b in zip(q0, q_there)]
    print("=" * 70)
    print(f"ABOUT TO MOVE. Delta (rad): {delta}  -- elbow only, ~5.7 deg")
    print(f"  From: {[round(v, 4) for v in q0]}")
    print(f"  To:   {[round(v, 4) for v in q_there]}")
    print(f"  Speed: {SPEED} rad/s   Accel: {ACCEL} rad/s^2")
    print("Confirm this looks correct and the cell is still clear. [y/N]")
    print("=" * 70)
    if input("> ").strip().lower() != "y":
        raise SystemExit("Aborted by operator before any motion.")

    validate_target(rtde_c, q_there)
    rtde_c.moveJ(full_q(q_there), SPEED, ACCEL, False)
    time.sleep(0.5)
    print(f"Actual position now: {rtde_r.getActualQ()[:3]}")

    print(f"\nMoving back to: {[round(v, 4) for v in q0]}")
    print("Confirm the return move too. [y/N]")
    if input("> ").strip().lower() != "y":
        raise SystemExit("Stopped before return move -- robot is left at "
                         "the nudged position. Use the pendant to move it "
                         "back manually, or re-run to continue.")
    validate_target(rtde_c, q0)
    rtde_c.moveJ(full_q(q0), SPEED, ACCEL, False)
    time.sleep(0.5)
    print(f"Actual position now: {rtde_r.getActualQ()[:3]}")

    print("\nIf the robot moved a small, smooth amount and returned")
    print("cleanly with no protective stop, you're ready to run")
    print("hw_run_sampling.py with n_queries=1 or 2 next.")
finally:
    rtde_c.disconnect()
    rtde_r.disconnect()
    print("Disconnected.")
