"""Run this FIRST, before hw_run_sampling.py or hw_run_policy.py.

Connects to URSim (or a real robot), reads and prints its current
state, and disconnects. Sends ZERO motion commands -- this only proves
the network path and API work, with no risk.

On URSim specifically: RTDEControlInterface will connect but then wait
for you to press Play in PolyScope (URSim's simulated teach pendant)
before it reports the program as running. If this script seems to
hang at "Connecting...", check the URSim window: the robot must be
powered on (top-left power icon -> ON -> release brakes if prompted)
and a program must be pressed Play on, not just loaded.

Usage:
    python3 smoke_test.py
"""
import hw_config as cfg

print(f"Target: {cfg.ROBOT_IP}")
print("Make sure URSim shows the robot powered ON and a program")
print("running (pressed Play), or this will hang waiting for that.")
print("Connecting...")

import rtde_control
import rtde_receive

rtde_c = rtde_control.RTDEControlInterface(cfg.ROBOT_IP)
rtde_r = rtde_receive.RTDEReceiveInterface(cfg.ROBOT_IP)

print(f"Control interface connected:  {rtde_c.isConnected()}")
print(f"Receive interface connected:  {rtde_r.isConnected()}")
print(f"Program running:              {rtde_c.isProgramRunning()}")
print(f"Robot mode (7 = RUNNING):     {rtde_r.getRobotMode()}")
print(f"Emergency stopped:            {rtde_r.isEmergencyStopped()}")
print(f"Protective stopped:           {rtde_r.isProtectiveStopped()}")
print(f"Current joint positions:      {rtde_r.getActualQ()}")
print(f"  (first 3, which the sim uses): {rtde_r.getActualQ()[:3]}")

rtde_c.disconnect()
rtde_r.disconnect()
print("\nDisconnected cleanly. If all the above looked sane and no")
print("motion happened, you're ready for the tiny motion test next.")
