"""Execute PRM / PRM+SC / RRT-Connect on a physical UR5e (or URSim) and
log results in the exact format make_tables.py expects.

Usage:
    python3 hw_run_sampling.py <prm|prm_sc|rrt> <s1|s2|s3> [n_queries]

Before running on a REAL robot:
  1. Validate against URSim first (see README_HARDWARE.md).
  2. Physically place bar obstacles at the (x, y) offsets in
     hw_config.SCENE_BARS_XY for the chosen scene, or edit that dict to
     match your actual cell -- understanding you are then testing a
     DIFFERENT scene than the one in the paper.
  3. Keep MOVEJ_SPEED_INIT / MOVEJ_ACCEL_INIT conservative for the
     first runs. A human must supervise with a hand on the e-stop.

CAVEAT (found via dry-run against a mock controller, not a real robot):
this script sends one waypoint per moveJ() call, so the robot fully
decelerates to zero at every intermediate waypoint -- there is no
path blending. For sampling-based planners whose paths have many
waypoints (raw PRM especially), this will read as rougher on hardware
than the simulation's *geometric* roughness metric, which measures
path curvature independent of execution dynamics. ur_rtde supports a
blended moveJ(path, asynchronous) overload (a list of
[q0..q5, speed, accel, blend_radius] rows) that avoids this, but its
exact blend-radius units/semantics were not independently verified
against source in this session (SDU Robotics hosts on GitLab, outside
this assistant's network allowlist) -- check ur_rtde's own examples
for your installed version before relying on it, rather than trusting
a guessed row format on a real robot.
"""
import json
import sys
import time

import numpy as np

import hw_config as cfg
from hw_common import (SafetyAbort, TrajectoryPoller, TrialLogger, connect,
                       full_q, print_preflight_banner, validate_target)
from env import Scene
from planners import PRM, RRTConnect

METHODS = {"prm", "prm_sc", "rrt"}
# make_tables.py (the analysis script used for the paper's simulated
# results) expects this exact directory name for RRT-Connect logs.
LOG_DIR_NAME = {"prm": "prm", "prm_sc": "prm_sc", "rrt": "rrt_connect"}


def build_real_scene(scene_name):
    """Scene built from the REAL-WORLD coordinates in hw_config.py."""
    return Scene(cfg.SCENE_BARS_XY[scene_name])


def all_waypoints_valid(rtde_c, W):
    """Pre-check the whole path before any motion starts. Returns True
    only if every waypoint clears both the local QLIM and the
    controller's own isJointsWithinSafetyLimits()."""
    try:
        for wp in W:
            validate_target(rtde_c, wp)
        return True
    except SafetyAbort as e:
        print(f"  path rejected before motion: {e}")
        return False


def run(method, scene_name, n_queries_arg):
    assert method in METHODS
    all_queries = json.load(open("queries.json"))[scene_name]
    if isinstance(n_queries_arg, list):
        by_idx = {q["query_idx"]: q for q in all_queries}
        missing = [i for i in n_queries_arg if i not in by_idx]
        if missing:
            raise SystemExit(f"query indices not found for {scene_name}: {missing}")
        queries = [by_idx[i] for i in n_queries_arg]
    else:
        queries = all_queries[:n_queries_arg]
    scene = build_real_scene(scene_name)
    print_preflight_banner(scene_name, method, len(queries))

    t0 = time.perf_counter()
    prm = PRM(scene, n_nodes=1500, k=12, seed=7) if method != "rrt" else None
    rrt = RRTConnect(scene, seed=7) if method == "rrt" else None
    print(f"Offline structure build time: {time.perf_counter()-t0:.1f} s")

    rtde_c, rtde_r = connect()
    poller = TrajectoryPoller(rtde_r, hz=50.0)
    logger = TrialLogger(scene_name, LOG_DIR_NAME[method])
    speed, accel = cfg.MOVEJ_SPEED_INIT, cfg.MOVEJ_ACCEL_INIT

    try:
        for q in queries:
            qi = q["query_idx"]
            qs, qg = np.array(q["q_start"]), np.array(q["q_goal"])
            print(f"\n--- query {qi} ---")

            t_plan0 = time.perf_counter()
            if method == "prm":
                W, _ = prm.query(qs, qg)
            elif method == "prm_sc":
                W, _ = prm.query(qs, qg)
                if W is not None:
                    W, _ = prm.shortcut(list(W), iters=120, seed=qi)
            else:
                W, _ = rrt.plan(qs, qg)
            t_plan_ms = (time.perf_counter() - t_plan0) * 1e3

            if W is None:
                print("  planner found no path -- logging as failure")
                logger.log_meta(qi, False, t_plan_ms, 0.0, False)
                continue
            if not all_waypoints_valid(rtde_c, W):
                logger.log_meta(qi, False, t_plan_ms, 0.0, False)
                continue

            # move to the start config first (untimed, matching the
            # simulation's convention that t_exec covers the query path)
            rtde_c.moveJ(full_q(W[0]), speed, accel, False)

            protective_stop, reached_all = False, True
            poller.start()
            try:
                for wp in W[1:]:
                    ok = rtde_c.moveJ(full_q(wp), speed, accel, False)
                    poller.check_safe()
                    if not ok:
                        reached_all = False
                        break
                # settle delay: give the poller >=1 full cycle to record
                # the truly-final resting position before stopping it,
                # otherwise the last logged sample can be a stale
                # mid-motion point (verified via dry-run against a mock
                # controller -- see hw_run_sampling dry-run notes) and
                # would cause spurious false-negative success calls.
                time.sleep(3.0 / 50.0)
            except SafetyAbort as e:
                print(f"  SAFETY ABORT during execution: {e}")
                protective_stop = True
                reached_all = False
                rtde_c.stopJ(2.0, False)
            finally:
                poller.stop()

            t_exec_s = poller.samples[-1][0] if poller.samples else 0.0
            final_q = (np.array(poller.samples[-1][1][:3])
                      if poller.samples else np.array(rtde_r.getActualQ()[:3]))
            success = (reached_all and not protective_stop
                      and np.linalg.norm(final_q - qg) <= cfg.GOAL_TOL)

            ts = [s[0] for s in poller.samples]
            qs_full = [s[1] for s in poller.samples]
            logger.log_trajectory(qi, ts, qs_full)
            logger.log_meta(qi, success, t_plan_ms, t_exec_s, protective_stop)
            print(f"  success={success}  t_plan={t_plan_ms:.1f}ms  "
                  f"t_exec={t_exec_s:.2f}s  n_samples={len(ts)}")
    finally:
        rtde_c.disconnect()
        rtde_r.disconnect()
        print("\nDisconnected.")


if __name__ == "__main__":
    if len(sys.argv) < 3:
        raise SystemExit(__doc__)
    arg = sys.argv[3] if len(sys.argv) > 3 else "50"
    n = [int(x) for x in arg.split(",")] if "," in arg else int(arg)
    run(sys.argv[1], sys.argv[2], n)
