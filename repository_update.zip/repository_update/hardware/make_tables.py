#!/usr/bin/env python3
"""
make_tables.py -- turn UR5e trial logs into the LaTeX rows of Table I.

Expected data layout (one CSV per trial):
    logs/<scene>/<method>/q<idx>.csv
        columns: t, q1..q6, planned (0/1 flag row optional)
    logs/<scene>/<method>/meta.csv
        columns: query_idx, success, t_plan_ms, t_exec_s, protective_stop

Methods: prm, prm_sc, rrt_connect, td3_her, sac_her
Scenes : s1, s2, s3

Usage:
    python make_tables.py logs/          # prints LaTeX rows + Wilcoxon tests
"""
import sys, glob, os
import numpy as np
import pandas as pd
from scipy.stats import wilcoxon

METHODS = ["prm", "prm_sc", "rrt_connect", "td3_her", "sac_her"]
LABELS  = {"prm": "PRM", "prm_sc": "PRM + SC", "rrt_connect": "RRT-Connect",
           "td3_her": "TD3+HER", "sac_her": "SAC+HER"}
BASELINE = "prm_sc"  # paired-test reference

def path_length(Q):
    return float(np.sum(np.linalg.norm(np.diff(Q, axis=0), axis=1)))

def roughness(Q, dt):
    # mean squared second derivative, Prianto et al. (2020)
    qdd = np.diff(Q, n=2, axis=0) / dt**2
    return float(np.mean(np.sum(qdd**2, axis=1)))

def load_method(root, scene, method):
    meta = pd.read_csv(os.path.join(root, scene, method, "meta.csv"))
    rows = []
    for _, m in meta.iterrows():
        rec = dict(query=int(m.query_idx), success=bool(m.success),
                   t_plan=float(m.t_plan_ms), t_exec=float(m.t_exec_s),
                   L=np.nan, R=np.nan)
        f = os.path.join(root, scene, method, f"q{int(m.query_idx)}.csv")
        if rec["success"] and os.path.exists(f):
            tr = pd.read_csv(f)
            Q = tr[[c for c in tr.columns if c.startswith("q")]].to_numpy()
            dt = float(np.median(np.diff(tr["t"].to_numpy())))
            rec["L"] = path_length(Q)
            rec["R"] = roughness(Q, dt)
        rows.append(rec)
    return pd.DataFrame(rows)

def main(root):
    scenes = sorted(d for d in os.listdir(root)
                    if os.path.isdir(os.path.join(root, d)))
    all_data = {m: [] for m in METHODS}
    for s in scenes:
        for m in METHODS:
            if os.path.isdir(os.path.join(root, s, m)):
                d = load_method(root, s, m); d["scene"] = s
                all_data[m].append(d)
    all_data = {m: pd.concat(v, ignore_index=True)
                for m, v in all_data.items() if v}

    print("% ---- paste into Table I ----")
    for m in METHODS:
        if m not in all_data: continue
        d = all_data[m]; ok = d[d.success]
        print(f"{LABELS[m]:<14}& {100*d.success.mean():5.1f} "
              f"& {ok.L.mean():.3f} $\\pm$ {ok.L.std():.3f} "
              f"& {100*ok.R.mean():.2f} $\\pm$ {100*ok.R.std():.2f} "
              f"& {ok.t_plan.mean():.1f} "
              f"& {ok.t_exec.mean():.2f} $\\pm$ {ok.t_exec.std():.2f}\\\\")

    # paired Wilcoxon vs baseline on path length (successful in both)
    if BASELINE in all_data:
        print("\n% ---- Wilcoxon signed-rank vs", LABELS[BASELINE], "----")
        b = all_data[BASELINE].set_index(["scene", "query"])
        for m in METHODS:
            if m == BASELINE or m not in all_data: continue
            x = all_data[m].set_index(["scene", "query"])
            j = b.join(x, lsuffix="_b", rsuffix="_m")
            j = j[(j.success_b) & (j.success_m)].dropna(subset=["L_b", "L_m"])
            if len(j) >= 10:
                W, p = wilcoxon(j.L_b, j.L_m)
                dpc = 100 * (j.L_m.mean() - j.L_b.mean()) / j.L_b.mean()
                print(f"% {LABELS[m]:<12} n={len(j):3d}  dL={dpc:+.2f}%%  "
                      f"W={W:.0f}  p={p:.4f}")

if __name__ == "__main__":
    main(sys.argv[1] if len(sys.argv) > 1 else "logs")
