"""Central configuration for hardware replication on a physical UR5e.

READ THIS FILE AND EDIT THE VALUES MARKED "*** SET THIS ***" BEFORE
RUNNING ANYTHING ON A REAL ROBOT. See README_HARDWARE.md first.
"""
import numpy as np

# ---------------------------------------------------------------------
# Connection
# ---------------------------------------------------------------------
# *** SET THIS *** -- IP address of the robot controller (or of URSim,
# Universal Robots' official offline simulator, e.g. "192.168.1.10" if
# running URSim in a local VM/Docker container on this machine).
# ALWAYS validate against URSim before pointing this at a real robot.
ROBOT_IP = "192.168.1.10"          # URSim default; change for real hardware

# ---------------------------------------------------------------------
# Safety limits -- deliberately conservative for initial validation.
# These do NOT match the robot's full mechanical range; they match the
# same restricted, elbow-consistent 3-DOF envelope used throughout the
# simulation (env.py: QLIM), so hardware trials are apples-to-apples
# with the simulated ones. Raise them only after you have visually
# confirmed correct, safe motion at these conservative values.
# ---------------------------------------------------------------------
QLIM = np.array([[-2.6, 2.6], [-3.05, -0.10], [-2.70, 2.70]])  # rad, joints 1-3

# Fixed wrist pose (joints 4,5,6). The simulation locks the wrist, so any
# constant, reachable wrist pose reproduces the study; this one points the
# tool roughly downward and is a reasonable default -- change if it
# collides with your gripper/tool or the physical cell.
WRIST_FIXED = [-1.5982, -1.5368, 0.0778]           # q4,q5,q6 [rad], from robot home pose

# Conservative motion limits for moveJ (sampling-based planner playback).
# ur_rtde defaults are speed=1.05 rad/s, acceleration=1.4 rad/s^2 -- START
# AT A SMALL FRACTION OF THESE for every new cell/scene until you have
# visually confirmed safe behaviour.
MOVEJ_SPEED_INIT = 0.30         # rad/s -- ~14% of ur_rtde's default 1.05
MOVEJ_ACCEL_INIT = 0.60         # rad/s^2
MOVEJ_SPEED_MAX = 0.50          # do not exceed this without a specific
MOVEJ_ACCEL_MAX = 0.80          # reason and a supervised, clear cell

# servoJ parameters for the closed-loop RL policies (TD3+HER / SAC+HER).
# speed/acceleration are documented by ur_rtde as unused in servoJ; motion
# smoothness is instead governed by time / lookahead_time / gain.
SERVOJ_TIME = 0.10              # control period [s]; matches ~1/10 Hz
                                 # loop below -- keep small (<=0.1) for a
                                 # responsive but still smooth policy step
SERVOJ_LOOKAHEAD = 0.10         # [s], recommended range [0.03, 0.2]
SERVOJ_GAIN = 300               # recommended range [100, 2000]

# ---------------------------------------------------------------------
# Scene definitions -- REAL-WORLD (x, y) bar-obstacle positions in
# metres relative to the robot base frame, IDENTICAL to env.py's SCENES
# dict. If you physically place cylindrical obstacles (radius ~0.05 m,
# height ~0.9 m -- e.g. a pool noodle over a dowel, or a cardboard
# tube) at exactly these offsets from the robot base, the trained
# TD3+HER / SAC+HER policies and the precomputed PRM/RRT-Connect paths
# all remain valid without any retraining or replanning.
#
# *** SET THIS *** if your physical cell places obstacles anywhere
# else: update these coordinates (and re-run hw_run_sampling.py's
# planning step, and retrain the policies against the new Scene before
# trusting them on hardware).
# ---------------------------------------------------------------------
SCENE_BARS_XY = {
    "s1": [(0.45, 0.10)],
    "s2": [(0.42, -0.30), (0.42, 0.30)],
    "s3": [(0.30, -0.38), (0.50, 0.00), (0.30, 0.38)],
}
BAR_RADIUS_M = 0.05
BAR_HEIGHT_M = 0.90

# ---------------------------------------------------------------------
# Episode / policy parameters -- must match training exactly (env.py)
# ---------------------------------------------------------------------
ALPHA = 0.25                    # joint-increment scale used in training
GOAL_TOL = 0.15                 # rad, success tolerance ||q - q_goal||
MAX_POLICY_STEPS = 120          # matches evaluate.py's rollout cap

# ---------------------------------------------------------------------
# Logging -- output layout matches make_tables.py exactly, so the
# existing analysis script works unmodified on real hardware logs.
# ---------------------------------------------------------------------
LOG_ROOT = "hw_logs"
