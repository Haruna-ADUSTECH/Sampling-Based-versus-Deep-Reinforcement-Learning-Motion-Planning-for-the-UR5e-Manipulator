"""Zero-motion check: ask ur_rtde's own (independent, library-maintained)
forward kinematics for the TCP position at the given joint angles, and
compare against both the pendant's reading and our own DH computation.
Sends no motion commands -- purely a read/compute check."""
import numpy as np
import rtde_control

q_deg = [-114.44, -25.15, -3.32, -91.57, -88.05, 4.46]
q_rad = list(np.radians(q_deg))

rtde_c = rtde_control.RTDEControlInterface("192.168.1.10")
pose = rtde_c.getForwardKinematics(q_rad)
print("ur_rtde's own getForwardKinematics() result:")
print(f"  X={pose[0]*1000:.2f}mm  Y={pose[1]*1000:.2f}mm  Z={pose[2]*1000:.2f}mm")
print(f"  RX={pose[3]:.3f}  RY={pose[4]:.3f}  RZ={pose[5]:.3f}")
rtde_c.disconnect()
