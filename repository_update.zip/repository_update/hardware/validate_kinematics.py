"""Independent validation of the simulated UR5e kinematic model.

Two separate checks, deliberately kept independent of env.py's own
derivation:
  (1) PARAMETER check -- compare the nominal DH values used in the
      simulation (and in the paper's Table I, sourced from Universal
      Robots' published DH page via Terreros et al. 2024) against the
      *separately maintained* ROS-Industrial calibration file
      ur_description/config/ur5e/default_kinematics.yaml, cloned fresh
      from https://github.com/ros-industrial/universal_robot.
  (2) CODE check -- re-implement forward kinematics from first
      principles using the standard 4x4 homogeneous DH transform
      (independent of env.py's hand-simplified closed-form formulas),
      and confirm the two implementations agree to float precision
      across many random configurations.
"""
import numpy as np

# ---------------------------------------------------------------
# (1) Parameter check against the official ROS-Industrial calibration
# ---------------------------------------------------------------
# These values were read directly from
# ur_description/config/ur5e/default_kinematics.yaml in a fresh clone
# of https://github.com/ros-industrial/universal_robot (retrieved
# 2026-07-27, hash 'calib_12788084448423163542' per that file's own
# hash field). Embedded here as constants so this script is standalone
# and re-runnable without needing that repo cloned locally.
official = {
    "d1": 0.1625,               # kinematics.shoulder.z
    "alpha1": 1.570796327,       # kinematics.upper_arm.roll
    "a2": -0.425,                # kinematics.forearm.x
    "d4": 0.1333,                # kinematics.wrist_1.z
    "a3": -0.3922,               # kinematics.wrist_1.x
    "d5": 0.0997,                # abs(kinematics.wrist_2.y)
    "alpha4": 1.570796327,       # kinematics.wrist_2.roll
    "d6": 0.0996,                # abs(kinematics.wrist_3.y)
}
nominal = {  # values used in env.py / the paper's Table I
    "d1": 0.163, "alpha1": np.pi / 2, "a2": -0.425, "d4": 0.134,
    "a3": -0.39225, "d5": 0.1, "alpha4": np.pi / 2, "d6": 0.1,
}

print("=" * 70)
print("(1) PARAMETER CHECK: simulation/paper values vs. official")
print("    ROS-Industrial calibration (independent source)")
print("=" * 70)
print(f"{'param':8s} {'nominal (used here)':>20s} {'official calib':>18s} "
      f"{'abs diff':>10s} {'rel diff':>10s}")
max_rel = 0.0
for k in nominal:
    nv, ov = nominal[k], official[k]
    ad = abs(nv - ov)
    rd = ad / max(abs(ov), 1e-9)
    max_rel = max(max_rel, rd)
    print(f"{k:8s} {nv:20.6f} {ov:18.6f} {ad:10.6f} {rd:10.4%}")
print(f"\nLargest relative difference: {max_rel:.3%} "
      f"(expected to be small -- 'nominal spec' vs 'this-unit calibration')")

# ---------------------------------------------------------------
# (2) Independent generic-DH-chain FK, cross-checked against env.py
# ---------------------------------------------------------------
import sys
import os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from env import fk_points as fk_points_env, D1, A2, A3


def dh_transform(theta, d, a, alpha):
    """Standard (Denavit 1955 / classic) homogeneous transform,
    written independently from env.py, straight from the textbook
    definition T = Rot_z(theta) Trans_z(d) Trans_x(a) Rot_x(alpha)."""
    ct, st = np.cos(theta), np.sin(theta)
    ca, sa = np.cos(alpha), np.sin(alpha)
    return np.array([
        [ct, -st * ca,  st * sa, a * ct],
        [st,  ct * ca, -ct * sa, a * st],
        [0,        sa,       ca,      d],
        [0,         0,        0,      1],
    ])


def fk_points_generic_dh(q1, q2, q3):
    """Positions of joint origins 1 (shoulder), 2 (elbow), 3 (wrist
    centre) via explicit 4x4 matrix chaining -- no shared code with
    env.py's fk_points beyond the DH parameter *values* being tested."""
    T = np.eye(4)
    pts = []
    dh_rows = [(q1, D1, 0, np.pi / 2),
               (q2, 0, A2, 0),
               (q3, 0, A3, 0)]
    for (theta, d, a, alpha) in dh_rows:
        T = T @ dh_transform(theta, d, a, alpha)
        pts.append(T[:3, 3].copy())
    return pts


rng = np.random.default_rng(0)
n_test = 2000
Q = rng.uniform([-3.0, -3.0, -3.0], [3.0, 3.0, 3.0], size=(n_test, 3))
max_err = 0.0
for q in Q:
    p1e, p2e, p3e = fk_points_env(q[None])
    p1e, p2e, p3e = p1e[0], p2e[0], p3e[0]
    p1g, p2g, p3g = fk_points_generic_dh(*q)
    err = max(np.max(np.abs(p1e - p1g)), np.max(np.abs(p2e - p2g)),
              np.max(np.abs(p3e - p3g)))
    max_err = max(max_err, err)

print()
print("=" * 70)
print("(2) CODE CHECK: env.py fk_points() vs. independent generic")
print("    4x4 homogeneous-DH-transform chain, "
      f"{n_test} random configurations")
print("=" * 70)
print(f"Maximum joint-origin position error across all {n_test} trials: "
      f"{max_err:.3e} m")
print("PASS" if max_err < 1e-9 else "FAIL",
      "-- the two independent implementations agree to floating-point"
      " precision" if max_err < 1e-9 else "-- DISCREPANCY DETECTED")
