"""Peak joint speed of every sampling-based hardware trial, estimated from the 50 Hz logs.

The speed is the largest absolute change of any of joints 1-3 over a 0.2 s window (10 samples), divided by the
elapsed time. With moveJ at 0.30 rad/s the peak should be about 0.30 rad/s in every trial. This is a check that the
same motion settings were in force in all three scenes, even though hw_config.py and hw_run_sampling.py carry later
modification times than some of the logs (see README_HARDWARE.md).

usage (from the repository root):
    python3 hardware/analysis/sampling_peak_speed.py hardware hardware/analysis/out/sampling_peak_speed.csv
"""
import csv, os, sys
import numpy as np

hw, out = sys.argv[1], sys.argv[2]
K = 10
rows = []
for scene in ('s1', 's2', 's3'):
    for method in ('prm', 'prm_sc', 'rrt_connect'):
        d = os.path.join(hw, 'hw_logs', scene, method)
        for r in csv.DictReader(open(os.path.join(d, 'meta.csv'))):
            qi = int(r['query_idx'])
            a = np.genfromtxt(os.path.join(d, f'q{qi}.csv'), delimiter=',', skip_header=1)
            t, Q = a[:, 0], a[:, 1:4]
            v = np.abs(Q[K:] - Q[:-K]) / (t[K:, None] - t[:-K, None])
            rows.append(dict(scene=scene, method=method, query=qi, peak_speed_rad_s=round(float(v.max()), 3),
                             median_sample_period_s=round(float(np.median(np.diff(t))), 4)))
with open(out, 'w', newline='') as fh:
    w = csv.DictWriter(fh, fieldnames=list(rows[0])); w.writeheader(); w.writerows(rows)
for scene in ('s1', 's2', 's3'):
    v = [r['peak_speed_rad_s'] for r in rows if r['scene'] == scene]
    print(f'{scene}: {len(v)} trials, peak speed min {min(v):.3f}  median {np.median(v):.3f}  max {max(v):.3f} rad/s')
