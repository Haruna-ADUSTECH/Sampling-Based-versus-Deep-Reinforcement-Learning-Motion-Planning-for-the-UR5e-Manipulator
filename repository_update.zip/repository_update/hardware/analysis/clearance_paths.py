"""Model-based clearance between the arm links and the bar obstacles for every
sampling-based hardware trial, computed from the logged 50 Hz joint angles.

For each trial we report two numbers, in metres:
  link_clear_min : smallest distance between the surface of the upper-arm or
                   forearm capsule (radius R_LINK) and the surface of a bar
                   (radius R_BAR) over the whole logged trajectory.
  grip_margin_min: smallest value of (distance from the wrist centre to a bar
                   axis) - (GRIPPER_REACH + R_BAR) over the trajectory. Positive
                   means the conservative gripper sphere stayed outside the bar.
Both come from the capsule geometry of hardware/env.py (the model the
planners used), not from an independent measurement of the real cell.

usage (from the repository root):
    python3 hardware/analysis/clearance_paths.py hardware hardware/analysis/out/clearance_paths.csv
"""
import csv, importlib.util, os, sys
import numpy as np

hw, out = sys.argv[1], sys.argv[2]
spec = importlib.util.spec_from_file_location('envH', os.path.join(hw, 'env.py'))
H = importlib.util.module_from_spec(spec); spec.loader.exec_module(H)

def clearances(Q, bars):
    p1, p2, p3 = H.fk_points(Q)
    link = np.full(len(Q), np.inf); grip = np.full(len(Q), np.inf)
    for bx, by in bars:
        lo = np.array([bx, by, 0.0]); hi = np.array([bx, by, 0.9])
        for A, B in ((p1, p2), (p2, p3)):
            link = np.minimum(link, H._segseg(A, B, lo[None], hi[None]) - (H.R_LINK + H.R_BAR))
        d = np.linalg.norm(p3 - H._closest_point_on_segment(p3, lo, hi), axis=-1)
        grip = np.minimum(grip, d - (H.GRIPPER_REACH + H.R_BAR))
    return link, grip

rows = []
for scene in ('s1', 's2', 's3'):
    bars = [tuple(b) for b in H.SCENES[scene].bars]
    for method in ('prm', 'prm_sc', 'rrt_connect'):
        d = os.path.join(hw, 'hw_logs', scene, method)
        for r in csv.DictReader(open(os.path.join(d, 'meta.csv'))):
            qi = int(r['query_idx']); f = os.path.join(d, f'q{qi}.csv')
            if not os.path.exists(f):
                continue
            a = np.genfromtxt(f, delimiter=',', skip_header=1)
            link, grip = clearances(a[:, 1:4], bars)
            rows.append(dict(scene=scene, method=method, query=qi,
                             link_clear_min=round(float(link.min()), 4),
                             grip_margin_min=round(float(grip.min()), 4)))
with open(out, 'w', newline='') as fh:
    w = csv.DictWriter(fh, fieldnames=list(rows[0])); w.writeheader(); w.writerows(rows)
print(len(rows), 'trials ->', out)
for scene in ('s1', 's2', 's3'):
    sub = [r for r in rows if r['scene'] == scene]
    if sub:
        m = min(sub, key=lambda r: r['link_clear_min'])
        print(scene, 'closest link-to-bar over all trials:', m['link_clear_min'], 'm  (', m['method'], 'q', m['query'], ')')
