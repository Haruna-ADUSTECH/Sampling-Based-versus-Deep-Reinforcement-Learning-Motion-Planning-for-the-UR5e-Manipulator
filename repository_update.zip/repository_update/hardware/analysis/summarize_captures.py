"""Turn terminal captures of hw_run_policy.py / hw_run_sampling.py runs into one row per query (no host names kept).
usage: summarize_captures.py <out.csv> <capture1.txt> [capture2.txt ...]"""
import csv, re, sys
out, files = sys.argv[1], sys.argv[2:]
rows = []
for f in files:
    txt = open(f, errors='replace').read().replace('\r', '\n').split('\n')
    cmd = servo = None; q = None; rej = None
    for ln in txt:
        s = ln.strip()
        m = re.search(r'python3 (hw_run_(?:policy|sampling)\.py .*)$', s)
        if m: cmd = m.group(1).strip(); continue
        m = re.match(r'servoJ: time=([\d.]+)s\s+lookahead=([\d.]+)s\s+gain=(\d+)', s)
        if m: servo = f'time={m.group(1)} lookahead={m.group(2)} gain={m.group(3)}'; continue
        m = re.match(r'--- query (\d+) ---', s)
        if m: q = int(m.group(1)); rej = None; continue
        m = re.match(r'step (\d+): target rejected (by controller safety check|-- would self-collide or hit a scene obstacle)', s)
        if m and rej is None: rej = f'step {m.group(1)}: ' + ('controller safety check' if 'controller' in m.group(2) else 'collision model'); continue
        m = re.match(r'success=(True|False)\s+steps=(\d+)\s+t_infer=([\d.]+)ms\s+t_exec=([\d.]+)s\s+timed_out=(True|False)', s)
        if m and cmd:
            rows.append(dict(command=cmd, servoJ=servo, query=q, success=m.group(1), steps=m.group(2), t_infer_ms=m.group(3), t_exec_s=m.group(4),
                             timed_out=m.group(5), first_rejection=rej or ''))
            continue
        m = re.match(r'success=(True|False)\s+t_plan=([\d.]+)ms\s+t_exec=([\d.]+)s', s)
        if m and cmd:
            rows.append(dict(command=cmd, servoJ='', query=q, success=m.group(1), steps='', t_infer_ms=m.group(2), t_exec_s=m.group(3), timed_out='', first_rejection=''))
w = csv.DictWriter(open(out, 'w', newline=''), fieldnames=['command', 'servoJ', 'query', 'success', 'steps', 't_infer_ms', 't_exec_s', 'timed_out', 'first_rejection'])
w.writeheader(); w.writerows(rows); print(len(rows), 'rows ->', out)
