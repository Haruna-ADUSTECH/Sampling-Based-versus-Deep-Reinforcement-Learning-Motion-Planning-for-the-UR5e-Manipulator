"""Recompute the sampling-based hardware tables from the raw 50 Hz logs, as make_tables.py does
(L over all six logged joints, R from the logged trajectory at its native rate).
Rows are printed with R multiplied by 100 (unit 1e-2 rad^2 s^-4), the unit used in the hardware tables of the paper.

usage (from the repository root):
    python3 hardware/analysis/verify_sampling_tables.py .
"""
import os, sys
import numpy as np, pandas as pd
root = sys.argv[1] + '/hardware/hw_logs'
def path_length(Q): return float(np.sum(np.linalg.norm(np.diff(Q, axis=0), axis=1)))
def roughness(Q, dt):
    qdd = np.diff(Q, n=2, axis=0) / dt**2
    return float(np.mean(np.sum(qdd**2, axis=1)))
for scene in ['s1', 's2', 's3']:
    print(f'--- {scene}')
    for m, lab in [('prm', 'PRM'), ('prm_sc', 'PRM+SC'), ('rrt_connect', 'RRT-Connect')]:
        meta = pd.read_csv(f'{root}/{scene}/{m}/meta.csv')
        rows = []
        for _, r in meta.iterrows():
            tr = pd.read_csv(f'{root}/{scene}/{m}/q{int(r.query_idx)}.csv')
            Q = tr[[c for c in tr.columns if c.startswith('q')]].to_numpy()
            dt = float(np.median(np.diff(tr['t'].to_numpy())))
            rows.append((int(r.query_idx), int(r.success), r.t_plan_ms, r.t_exec_s, path_length(Q), roughness(Q, dt), path_length(Q[:, :3]), dt, len(tr)))
        d = pd.DataFrame(rows, columns=['q', 'ok', 'tp', 'te', 'L', 'R', 'L3', 'dt', 'n'])
        print(f'{lab:<12} n={len(d)} succ={d.ok.mean()*100:.0f}%  L={d.L.mean():.3f}±{d.L.std():.3f}  R100={100*d.R.mean():.2f}±{100*d.R.std():.2f}  tplan={d.tp.mean():.1f}  texec={d.te.mean():.2f}±{d.te.std():.2f}   (L3 joints-only={d.L3.mean():.3f}±{d.L3.std():.3f}; dt~{d.dt.median():.4f}; queries {list(d.q)})')
