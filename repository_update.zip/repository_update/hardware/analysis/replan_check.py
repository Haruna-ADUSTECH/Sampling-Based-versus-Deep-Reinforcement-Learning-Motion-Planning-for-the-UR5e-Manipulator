"""Re-run the seeded planners offline (same code, same seeds, same query order as the hardware scripts) and compare the
planned path with the path actually logged on the robot.

usage (from the repository root):
    python3 hardware/analysis/replan_check.py . hardware/analysis/out/replan_check.csv
"""
import importlib.util, json, sys, os
import numpy as np, pandas as pd
pkg = sys.argv[1]
sys.path.insert(0, f'{pkg}/hardware')          # planners.py does `from env import QLIM`
def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path); m = importlib.util.module_from_spec(spec); sys.modules[name] = m; spec.loader.exec_module(m); return m
envH = load('env', f'{pkg}/hardware/env.py')
pl = load('planners', f'{pkg}/hardware/planners.py')
queries = json.load(open(f'{pkg}/hardware/queries.json'))
def plen(W): return float(np.sum(np.linalg.norm(np.diff(W, axis=0), axis=1)))
out = []
for scene in ['s1', 's2', 's3']:
    sc = envH.Scene([tuple(b) for b in envH.SCENES[scene].bars])
    prm = pl.PRM(sc, n_nodes=1500, k=12, seed=7)
    for method in ['prm', 'prm_sc', 'rrt_connect']:
        meta = pd.read_csv(f'{pkg}/hardware/hw_logs/{scene}/{method}/meta.csv')
        rrt = pl.RRTConnect(sc, seed=7) if method == 'rrt_connect' else None
        for _, r in meta.iterrows():
            qi = int(r.query_idx); q = [x for x in queries[scene] if x['query_idx'] == qi][0]
            qs, qg = np.array(q['q_start']), np.array(q['q_goal'])
            if method == 'prm': W, _ = prm.query(qs, qg)
            elif method == 'prm_sc':
                W, _ = prm.query(qs, qg); W, _ = prm.shortcut(list(W), iters=120, seed=qi)
            else: W, _ = rrt.plan(qs, qg)
            tr = pd.read_csv(f'{pkg}/hardware/hw_logs/{scene}/{method}/q{qi}.csv'); Q = tr[['q1', 'q2', 'q3']].to_numpy()
            Lp = plen(W); Ll = plen(Q)
            # endpoint check
            out.append(dict(scene=scene, method=method, q=qi, segments=len(W) - 1, L_planned=Lp, L_logged=Ll, rel_diff_pct=100 * (Ll - Lp) / Lp,
                            end_err=float(np.linalg.norm(Q[-1] - qg)), start_err=float(np.linalg.norm(Q[0] - qs))))
df = pd.DataFrame(out); pd.set_option('display.width', 200)
print(df.round(3).to_string(index=False))
print('\nrel diff (logged vs planned length) %: mean', round(df.rel_diff_pct.mean(), 3), ' abs max', round(df.rel_diff_pct.abs().max(), 3))
print('max final-goal error [rad]', round(df.end_err.max(), 4), ' max start error', round(df.start_err.max(), 4))
print('segment counts by method/scene:'); print(df.groupby(['scene', 'method']).segments.apply(list).to_string())
df.to_csv(sys.argv[2], index=False)
