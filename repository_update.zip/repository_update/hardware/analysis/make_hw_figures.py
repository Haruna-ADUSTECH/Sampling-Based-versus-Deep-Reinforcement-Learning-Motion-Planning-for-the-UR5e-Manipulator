"""Fig. 9 (13 successful PRM+SC runs on S1) and Fig. 14 (learned planners: simulation versus hardware).

Same figure rules as make_figures.py: vector output, Type 42 fonts, Arial-metric sans serif at 8 pt, 174 mm or
84 mm wide canvas, no titles inside the artwork, panel letters in lower case, hatch patterns as well as colour.
All numbers are typed in from Table "hwtrials" and Table "rlhw" of the manuscript, which come from the raw logs
in hardware/hw_logs and the analysis in hardware/analysis.

Usage: python3 make_hw_figures.py <output_dir>
"""
import sys, os
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.patches import Patch
import numpy as np

out = sys.argv[1]
os.makedirs(out, exist_ok=True)
MM = 1 / 25.4
plt.rcParams.update({
    'font.family': 'Liberation Sans', 'font.size': 8, 'axes.labelsize': 8, 'xtick.labelsize': 8,
    'ytick.labelsize': 8, 'legend.fontsize': 8, 'axes.linewidth': 0.6, 'xtick.major.width': 0.6,
    'ytick.major.width': 0.6, 'xtick.major.size': 2.5, 'ytick.major.size': 2.5, 'patch.linewidth': 0.6,
    'hatch.linewidth': 0.5, 'pdf.fonttype': 42, 'ps.fonttype': 42, 'mathtext.fontset': 'custom',
    'mathtext.rm': 'Liberation Sans', 'mathtext.it': 'Liberation Sans:italic',
    'mathtext.bf': 'Liberation Sans:bold', 'axes.spines.top': False, 'savefig.transparent': False,
})

# ------------------------------------------------------------------ Fig9
# 13 successful PRM+SC runs on S1, grouped by query. Within a group the runs are in log order and the last
# bar (hatched) is the run that enters the cross-method comparison (last success per query).
runs = {0: [13.744, 13.744, 13.747, 13.746, 13.749],
        1: [16.446, 16.446],
        2: [5.373, 5.388],
        3: [14.570, 14.552],
        4: [16.724, 16.724]}
segs = {0: 1, 1: 4, 2: 1, 3: 3, 4: 2}
fig, ax = plt.subplots(figsize=(84 * MM, 2.3))
fig.subplots_adjust(left=0.15, right=0.985, top=0.95, bottom=0.27)
xpos, ticks, labels = 0.0, [], []
for qk, vals in runs.items():
    x0 = xpos
    for j, t in enumerate(vals):
        last = (j == len(vals) - 1)
        ax.bar(xpos, t, width=0.82, color='#B2DF8A' if last else '#E5F2D6', edgecolor='black',
               hatch='////' if last else '', linewidth=0.6, zorder=2)
        xpos += 1.0
    ax.text(xpos - 1.0, vals[-1] + 0.35, f'{vals[-1]:.1f}', ha='center', va='bottom', fontsize=7)
    ticks.append((x0 + xpos - 1.0) / 2)
    labels.append(f'q{qk}\n{segs[qk]} seg.')
    xpos += 0.7
ax.set_xticks(ticks); ax.set_xticklabels(labels)
ax.set_xlim(-0.7, xpos - 0.7 - 0.3); ax.set_ylim(0, 20)
ax.set_ylabel('Execution time [s]')
ax.yaxis.grid(True, linewidth=0.3, color='#BBBBBB', zorder=0); ax.set_axisbelow(True)
handles = [Patch(facecolor='#E5F2D6', edgecolor='black', label='Earlier run of the query'),
           Patch(facecolor='#B2DF8A', edgecolor='black', hatch='////', label='Run used in the cross-method table')]
fig.legend(handles=handles, loc='lower center', ncol=2, frameon=False, handlelength=1.6, columnspacing=1.2,
           bbox_to_anchor=(0.5, 0.0), fontsize=7)
fig.savefig(os.path.join(out, 'Fig9.pdf')); plt.close(fig)

# ------------------------------------------------------------------ Fig14
# per scene: policies SAC+HER, TD3+HER; [bare-model sim (50), gate sim (50), hardware (tested)]
data = {
    'S1': {'SAC+HER': dict(bare=(50, 50), gate=(43, 50), hw=(6, 10), same=(7, 10)),
           'TD3+HER': dict(bare=(50, 50), gate=(40, 50), hw=(5, 9),  same=(6, 9))},
    'S3': {'SAC+HER': dict(bare=(50, 50), gate=(38, 50), hw=(7, 10), same=(8, 10)),
           'TD3+HER': dict(bare=(50, 50), gate=(34, 50), hw=(6, 8),  same=(6, 8))},
}
def wilson(k, n, z=1.96):
    p = k / n; d = 1 + z * z / n
    c = (p + z * z / (2 * n)) / d; h = z * np.sqrt(p * (1 - p) / n + z * z / (4 * n * n)) / d
    return c - h, c + h
cond = [('bare', 'Simulation as in the original study, 50 queries', '#F0F0F0', ''),
        ('gate', 'Simulation with the run-time gate, 50 queries', '#BDBDBD', '////'),
        ('hw',   'Hardware, tested queries (bars: 95% Wilson interval)', '#8DD3C7', 'xxxx')]
fig, axs = plt.subplots(1, 2, figsize=(174 * MM, 2.75), sharey=True, gridspec_kw=dict(wspace=0.06))
fig.subplots_adjust(left=0.065, right=0.995, top=0.92, bottom=0.33)
bw = 0.24
for ax, (scn, d) in zip(axs, data.items()):
    for gi, pol in enumerate(['SAC+HER', 'TD3+HER']):
        for ci, (key, lab, fc, ht) in enumerate(cond):
            k, n = d[pol][key]; v = 100 * k / n; xpos = gi + (ci - 1) * (bw + 0.02)
            ax.bar(xpos, v, width=bw, color=fc, edgecolor='black', hatch=ht, linewidth=0.6, zorder=2)
            ax.text(xpos, v + 2.0 if key != 'hw' else min(100 * wilson(k, n)[1] + 2.0, 104), f'{k}/{n}',
                    ha='center', va='bottom', fontsize=6.5, zorder=5)
            if key == 'hw':
                lo, hi = wilson(k, n)
                ax.errorbar(xpos, v, yerr=[[v - 100 * lo], [100 * hi - v]], fmt='none', ecolor='black',
                            elinewidth=0.7, capsize=2.0, capthick=0.7, zorder=4)
        k, n = d[pol]['same']
        ax.plot([gi + (2 - 1) * (bw + 0.02) + 0.0], [100 * k / n], marker='D', ms=4.6, mfc='white',
                mec='black', mew=0.9, zorder=6, ls='none')
    ax.set_xticks([0, 1]); ax.set_xticklabels(['SAC+HER', 'TD3+HER'])
    ax.set_ylim(0, 112); ax.set_yticks([0, 20, 40, 60, 80, 100])
    ax.yaxis.grid(True, linewidth=0.3, color='#BBBBBB', zorder=0); ax.set_axisbelow(True)
    ax.text(0.01, 1.02, '(a) Scene S1' if scn == 'S1' else '(b) Scene S3', transform=ax.transAxes,
            fontweight='bold', ha='left', va='bottom', fontsize=8)
axs[0].set_ylabel('Success rate [%]'); axs[1].tick_params(axis='y', length=0); axs[1].spines['left'].set_visible(False)
handles = [Patch(facecolor=fc, edgecolor='black', hatch=ht, label=lab, linewidth=0.6) for _, lab, fc, ht in cond]
handles.append(Line2D([0], [0], marker='D', ms=4.6, mfc='white', mec='black', mew=0.9, ls='none',
                      label='Simulation with the gate, same queries as the hardware bar'))
fig.legend(handles=handles, loc='lower center', ncol=2, frameon=False, handlelength=1.8, columnspacing=1.6,
           bbox_to_anchor=(0.5, 0.0), fontsize=7.5)
fig.savefig(os.path.join(out, 'Fig14.pdf')); plt.close(fig)
print('written to', out)
