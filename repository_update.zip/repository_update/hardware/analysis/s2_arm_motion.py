"""Did the arm move in the scene-S2 learned-policy trials?

For every 50 Hz log in hw_logs/s2/sac_her this prints the distance (rad, joints 1-3) between the first logged
position and the start of the query, the total joint travel during the trial, and the largest excursion of each
joint from its first logged value. In the failing trials of the S2 fault the arm does not move at all and stays
at the start configuration of an earlier query (Section 7.7 of the paper). Only the logs of the last run of each
query survive, because a log file is overwritten when the same query is run again.

usage (from the repository root):
    python3 hardware/analysis/s2_arm_motion.py hardware hardware/analysis/out/s2_arm_motion.csv
"""
import csv, json, os, sys
import numpy as np

hw, out = sys.argv[1], sys.argv[2]
queries = {q['query_idx']: q for q in json.load(open(os.path.join(hw, 'queries.json')))['s2']}
rows = []
for qi in range(10):
    f = os.path.join(hw, 'hw_logs', 's2', 'sac_her', f'q{qi}.csv')
    if not os.path.exists(f):
        continue
    a = np.genfromtxt(f, delimiter=',', skip_header=1)
    t, Q = a[:, 0], a[:, 1:4]
    qs, qg = np.array(queries[qi]['q_start']), np.array(queries[qi]['q_goal'])
    rows.append(dict(query=qi, samples=len(t), duration_s=round(float(t[-1]), 2),
                     first_to_start_rad=round(float(np.linalg.norm(Q[0] - qs)), 3),
                     last_to_goal_rad=round(float(np.linalg.norm(Q[-1] - qg)), 3),
                     travel_rad=round(float(np.sum(np.linalg.norm(np.diff(Q, axis=0), axis=1))), 3),
                     max_excursion_rad=round(float(np.abs(Q - Q[0]).max()), 5),
                     first_q1=round(float(Q[0, 0]), 4), first_q2=round(float(Q[0, 1]), 4), first_q3=round(float(Q[0, 2]), 4)))
with open(out, 'w', newline='') as fh:
    w = csv.DictWriter(fh, fieldnames=list(rows[0])); w.writeheader(); w.writerows(rows)
for r in rows:
    print(r)
