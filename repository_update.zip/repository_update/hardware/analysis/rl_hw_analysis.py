#!/usr/bin/env python3
"""Reproduce every number of the learned-planner hardware section from the raw logs.

usage (from the repository root):
    python3 hardware/analysis/rl_hw_analysis.py hardware hardware/analysis/out env.py

  hardware  folder with env.py (gripper-aware model), queries.json, models/ and hw_logs/
  out       folder that receives the three result files
  env.py    (optional) the original bare-arm env.py of the simulation study; without it the 'bare' column of the
            50-query simulations is skipped

It writes rl_hw_attempts.csv (every logged attempt, annotated), rl_hw_trials.csv (the reported trials with the
gate-matched simulation outcome), rl_hw_path_fidelity.csv and rl_hw_summary.json.

Simulation rule (identical to hw_run_policy.py): target = clip(q + 0.25 a); a target flagged by the collision model is
replaced by holding the current state; success when ||q - g|| <= 0.15 within 120 steps; deterministic actions
(TD3 actor output, SAC tanh of the mean)."""
import importlib.util, json, math, os, sys
import numpy as np, pandas as pd

hw, out = sys.argv[1], sys.argv[2]
os.makedirs(out, exist_ok=True)
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from ptload import Actor

def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path); m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m); return m
H = load('env_hw', f'{hw}/env.py')
queries = json.load(open(f'{hw}/queries.json'))
ALPHA, TOL, CAP = 0.25, 0.15, 120

def wilson(k, n, z=1.959964):
    if n == 0: return (float('nan'), float('nan'))
    p = k / n; d = 1 + z * z / n
    c = (p + z * z / (2 * n)) / d; h = z * math.sqrt(p * (1 - p) / n + z * z / (4 * n * n)) / d
    return (c - h, c + h)

def rollout(actor, scene, qs, qg):
    q = np.array(qs, float); rej = 0
    for t in range(1, CAP + 1):
        a = actor(q, qg); tgt = np.clip(q + ALPHA * a, H.QLIM[:, 0], H.QLIM[:, 1])
        if scene.in_collision(tgt[None])[0]: rej += 1
        else: q = tgt
        if np.linalg.norm(q - qg) <= TOL: return True, t, rej
    return False, CAP, rej

# ---- which rows of each meta.csv are reported (1-based data rows). Everything else is a development run.
# Reconstructed from the order of the rows and the terminal captures of each run; see README_HARDWARE.md.
KEEP = {('s1', 'sac_her'): [9, 10, 14, 15, 16, 22, 23, 24, 25, 26]}          # all other files: every row is reported
NOTE = {('s1', 'sac_her'): {
    **{r: 'development run before the final script (unpaced loop or controller left in a bad state)' for r in range(1, 9)},
    **{r: 'final settings (servoJ time 0.1 s)' for r in (9, 10, 14, 15, 16)},
    **{r: 'servoJ time 0.5 s test, not the reported setting' for r in (11, 12, 13)},
    **{r: 'final settings, first of two identical passes over queries 5-9' for r in range(17, 22)},
    **{r: 'final settings, repeat pass over queries 5-9 (same outcomes)' for r in range(22, 27)}}}

attempts, trials = [], []
for scene in ['s1', 's2', 's3']:
    for algo in ['sac', 'td3']:
        key = (scene, f'{algo}_her'); mp = f'{hw}/hw_logs/{scene}/{algo}_her/meta.csv'
        if not os.path.exists(mp): continue
        meta = pd.read_csv(mp)
        act = Actor(f'{hw}/models/{algo}_{scene}.pt', algo)
        sc = H.Scene([tuple(b) for b in H.SCENES[scene].bars])
        keep = KEEP.get(key, list(range(1, len(meta) + 1))) if scene != 's2' else []
        for i, r in meta.iterrows():
            row = i + 1
            attempts.append(dict(scene=scene, algo=algo, row=row, query=int(r.query_idx), success=int(r.success), t_exec_s=round(r.t_exec_s, 2),
                                 reported=int(row in keep),
                                 note=NOTE.get(key, {}).get(row, 'scene S2: excluded (controller fault)' if scene == 's2' else 'reported')))
        if scene == 's2': continue
        for row in keep:
            r = meta.iloc[row - 1]; qi = int(r.query_idx)
            qq = [x for x in queries[scene] if x['query_idx'] == qi][0]
            ok, steps, rej = rollout(act, sc, np.array(qq['q_start']), np.array(qq['q_goal']))
            trials.append(dict(scene=scene, algo=algo, query=qi, hw_success=int(r.success), hw_t_exec_s=round(r.t_exec_s, 2),
                               hw_steps=int(round(r.t_exec_s / 0.1)), sim_success=int(ok), sim_steps=steps, sim_rejections=rej))
A = pd.DataFrame(attempts); T = pd.DataFrame(trials)
A.to_csv(f'{out}/rl_hw_attempts.csv', index=False); T.to_csv(f'{out}/rl_hw_trials.csv', index=False)

summ = {}
def cnt(df): return int(df.shape[0]), int(df.hw_success.sum()), int(df.sim_success.sum())
for scene in ['s1', 's3']:
    for algo in ['sac', 'td3']:
        d = T[(T.scene == scene) & (T.algo == algo)]
        n, hws, sms = cnt(d)
        summ[f'{scene}_{algo}'] = dict(n=n, hw=hws, sim_gate=sms, hw_ci=wilson(hws, n), queries=sorted(d['query'].tolist()))
for algo in ['sac', 'td3']:
    d = T[T.algo == algo]; n, hws, sms = cnt(d)
    summ[f'pooled_{algo}'] = dict(n=n, hw=hws, sim_gate=sms, hw_ci=wilson(hws, n), sim_ci=wilson(sms, n))
n, hws, sms = cnt(T)
agree = int((T.hw_success == T.sim_success).sum())
simok = T[T.sim_success == 1]; simfail = T[T.sim_success == 0]
summ['all'] = dict(n=n, hw=hws, sim_gate=sms, agree=agree, agree_ci=wilson(agree, n),
                   sim_solved=int(len(simok)), hw_given_sim_solved=int(simok.hw_success.sum()), hw_given_sim_solved_ci=wilson(int(simok.hw_success.sum()), len(simok)),
                   sim_failed=int(len(simfail)), hw_given_sim_failed=int(simfail.hw_success.sum()),
                   discordant=T[T.hw_success != T.sim_success][['scene', 'algo', 'query', 'hw_success', 'sim_success']].to_dict('records'))
# common queries for the two algorithms
for scene in ['s1', 's3']:
    qs_common = sorted(set(T[(T.scene == scene) & (T.algo == 'sac')]['query']) & set(T[(T.scene == scene) & (T.algo == 'td3')]['query']))
    summ[f'common_{scene}'] = qs_common
common = {a: T[(T.algo == a) & (((T.scene == 's1') & T['query'].isin(summ['common_s1'])) | ((T.scene == 's3') & T['query'].isin(summ['common_s3'])))] for a in ['sac', 'td3']}
summ['common_pooled'] = {a: dict(n=len(d), hw=int(d.hw_success.sum()), sim_gate=int(d.sim_success.sum())) for a, d in common.items()}

# full 50-query simulations: bare-arm (original env) and gate (hardware env)
A_env = load('env_orig', sys.argv[3]) if len(sys.argv) > 3 else None
full = {}
for scene in ['s1', 's2', 's3']:
    bars = [tuple(b) for b in H.SCENES[scene].bars]
    for algo in ['sac', 'td3']:
        act = Actor(f'{hw}/models/{algo}_{scene}.pt', algo)
        res = {'gate': sum(rollout(act, H.Scene(bars), np.array(q['q_start']), np.array(q['q_goal']))[0] for q in queries[scene])}
        if A_env is not None:
            res['bare'] = sum(rollout(act, A_env.Scene(bars), np.array(q['q_start']), np.array(q['q_goal']))[0] for q in queries[scene])
        full[f'{scene}_{algo}'] = res
summ['full50'] = full

# step inflation and path fidelity on successful trials whose logged trajectory belongs to the reported run
def traj(scene, algo, qi): return pd.read_csv(f'{hw}/hw_logs/{scene}/{algo}_her/q{qi}.csv')
infl, cham = [], []
for _, r in T[(T.hw_success == 1) & (T.sim_success == 1)].iterrows():
    if r.scene == 's1' and r.algo == 'sac' and r['query'] in (0, 1): continue      # trajectory file belongs to the 0.5 s test run
    tr = traj(r.scene, r.algo, r['query']); Q = tr[['q1', 'q2', 'q3']].to_numpy()
    qq = [x for x in queries[r.scene] if x['query_idx'] == r['query']][0]
    act = Actor(f'{hw}/models/{r.algo}_{r.scene}.pt', r.algo); sc = H.Scene([tuple(b) for b in H.SCENES[r.scene].bars])
    q = np.array(qq['q_start'], float); g = np.array(qq['q_goal']); path = [q.copy()]
    for _ in range(CAP):
        a = act(q, g); tgt = np.clip(q + ALPHA * a, H.QLIM[:, 0], H.QLIM[:, 1])
        if not sc.in_collision(tgt[None])[0]: q = tgt
        path.append(q.copy())
        if np.linalg.norm(q - g) <= TOL: break
    path = np.array(path)
    dens = np.vstack([path[i] + (path[i + 1] - path[i]) * np.linspace(0, 1, 6)[:-1, None] for i in range(len(path) - 1)] + [path[-1:]])
    d = np.linalg.norm(Q[:, None, :] - dens[None, :, :], axis=-1).min(1)
    cham.append(dict(scene=r.scene, algo=r.algo, query=r['query'], mean_dev=float(d.mean()), max_dev=float(d.max())))
    infl.append(r.hw_steps / r.sim_steps)
C = pd.DataFrame(cham)
summ['fidelity'] = dict(n=len(C), mean_dev_mean=float(C.mean_dev.mean()), mean_dev_max=float(C.mean_dev.max()), max_dev_max=float(C.max_dev.max()),
                        step_inflation_median=float(np.median(infl)), step_inflation_range=(float(min(infl)), float(max(infl))))
C.to_csv(f'{out}/rl_hw_path_fidelity.csv', index=False)

# realised fraction of each commanded increment per 0.1 s control period (successful trials with a matching trajectory file)
ratios = []
for _, r in T[T.hw_success == 1].iterrows():
    if r.scene == 's1' and r.algo == 'sac' and r['query'] in (0, 1): continue
    tr = traj(r.scene, r.algo, r['query']); t = tr['t'].to_numpy(); Q = tr[['q1', 'q2', 'q3']].to_numpy()
    qq = [x for x in queries[r.scene] if x['query_idx'] == r['query']][0]; g = np.array(qq['q_goal'])
    act = Actor(f'{hw}/models/{r.algo}_{r.scene}.pt', r.algo); sc = H.Scene([tuple(b) for b in H.SCENES[r.scene].bars])
    idx = lambda tt: int(np.searchsorted(t, tt, side='right') - 1)
    for k in range(1, int(round(r.hw_t_exec_s / 0.1)) - 1):
        sk, sk1 = Q[idx((k - 1) * 0.1)], Q[idx(k * 0.1)]
        tgt = np.clip(sk + ALPHA * act(sk, g), H.QLIM[:, 0], H.QLIM[:, 1])
        if sc.in_collision(tgt[None])[0]: continue
        cmd = tgt - sk
        if np.linalg.norm(cmd) < 0.02: continue
        ratios.append(float(((sk1 - sk) @ cmd) / (cmd @ cmd)))
ratios = np.array(ratios)
summ['tracking'] = dict(n_steps=int(len(ratios)), median=float(np.median(ratios)), q25=float(np.percentile(ratios, 25)), q75=float(np.percentile(ratios, 75)))
json.dump(summ, open(f'{out}/rl_hw_summary.json', 'w'), indent=1, default=float)
print(json.dumps(summ, indent=1, default=float))
