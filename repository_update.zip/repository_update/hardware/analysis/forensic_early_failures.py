"""Consistency check for the six failed S1 PRM+SC attempts that precede the collision-model correction.

usage (from the repository root):
    python3 hardware/analysis/forensic_early_failures.py . hardware/queries_original_bare_arm.json

Plans old query 0 (original frozen set, bare-arm model A) with the same seeds as the hardware script, then
asks where along the first moveJ segment the hardware model H starts to flag the interpolated joint path,
and how far the leading joint had travelled at the logged failure time (moveJ 0.30 rad/s, 0.60 rad/s^2)."""
import importlib.util, json, sys
import numpy as np
pkg, oldq = sys.argv[1], sys.argv[2]
def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path); m = importlib.util.module_from_spec(spec)
    sys.modules[name] = m; spec.loader.exec_module(m); return m
A = load('env', f'{pkg}/env.py')            # planners.py imports `env`
P = load('planners', f'{pkg}/planners.py')
H = load('envH', f'{pkg}/hardware/env.py')
qs_all = json.load(open(oldq))['s1']
q0 = [q for q in qs_all if q['query_idx'] == 0][0]
qs, qg = np.array(q0['q_start']), np.array(q0['q_goal'])
sceneA = A.SCENES['s1']; sceneH = H.SCENES['s1']
print('old q0: start invalid under H:', bool(sceneH.in_collision(qs[None])[0]), ' goal invalid under H:', bool(sceneH.in_collision(qg[None])[0]))
prm = P.PRM(sceneA, n_nodes=1500, k=12, seed=7)
W, _ = prm.query(qs, qg)
W, _ = prm.shortcut(list(W), iters=120, seed=0)
W = np.array(W); print('segments:', len(W) - 1)
def move_time(d, v=0.30, a=0.60):
    ta = v / a
    return 2 * np.sqrt(d / a) if d < a * ta ** 2 else 2 * ta + (d - a * ta ** 2) / v
def lead_at(t, v=0.30, a=0.60):
    ta = v / a
    return 0.5 * a * t * t if t <= ta else 0.5 * a * ta ** 2 + v * (t - ta)
t_fail = 2.1525
print(f'leading-joint travel at t={t_fail}s: {lead_at(t_fail):.3f} rad')
t_cum = 0.0
for i in range(len(W) - 1):
    a_, b_ = W[i], W[i + 1]
    lead = np.max(np.abs(b_ - a_)); T = move_time(lead)
    n = 400; s = np.linspace(0, 1, n)
    Q = a_[None] + s[:, None] * (b_ - a_)[None]
    flagH = sceneH.in_collision(Q); flagA = sceneA.in_collision(Q)
    first = np.argmax(flagH) if flagH.any() else None
    print(f'seg {i+1}: lead {lead:.3f} rad, duration {T:.2f} s, starts at t={t_cum:.2f} s;  flagged by A: {bool(flagA.any())};  flagged by H: {bool(flagH.any())}',
          end='')
    if first is not None:
        print(f'  first H flag at {s[first]*lead:.3f} rad of leading-joint travel into the segment; H-flagged fraction {flagH.mean():.2f}')
        runs = np.flatnonzero(np.diff(np.r_[0, flagH.astype(int), 0]))
        print('   flagged intervals (leading-joint travel, rad):', [(round(float(s[runs[k]]*lead),3), round(float(s[min(runs[k+1],n-1)]*lead),3)) for k in range(0, len(runs), 2)])
    else:
        print()
    t_cum += T
