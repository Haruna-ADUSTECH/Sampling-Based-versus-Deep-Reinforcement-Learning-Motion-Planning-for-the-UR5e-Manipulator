"""Zero-motion diagnostic. Reads the robot's OWN current joint angles
and OWN current TCP pose, guaranteed from the same instant (no manual
pendant reading, no risk of the robot moving between two readings).
Also recomputes our own DH-based FK for those exact joint angles, for a
direct three-way comparison. Sends no motion commands whatsoever.
"""
import numpy as np
import rtde_control
import rtde_receive

import hw_config as cfg


def dh_transform(theta, d, a, alpha):
    ct, st = np.cos(theta), np.sin(theta)
    ca, sa = np.cos(alpha), np.sin(alpha)
    return np.array([[ct, -st * ca, st * sa, a * ct],
                     [st, ct * ca, -ct * sa, a * st],
                     [0, sa, ca, d],
                     [0, 0, 0, 1]])


D1, A2, A3 = 0.163, -0.425, -0.39225
D4, ALPHA4 = 0.134, np.pi / 2
D5, ALPHA5 = 0.1, -np.pi / 2
D6, ALPHA6 = 0.1, 0.0


def our_fk(q_rad):
    q1, q2, q3, q4, q5, q6 = q_rad
    T = dh_transform(q1, D1, 0, np.pi / 2)
    T = T @ dh_transform(q2, 0, A2, 0)
    T = T @ dh_transform(q3, 0, A3, 0)
    T = T @ dh_transform(q4, D4, 0, ALPHA4)
    T = T @ dh_transform(q5, D5, 0, ALPHA5)
    T = T @ dh_transform(q6, D6, 0, ALPHA6)
    return T[:3, 3]


rtde_c = rtde_control.RTDEControlInterface(cfg.ROBOT_IP)
rtde_r = rtde_receive.RTDEReceiveInterface(cfg.ROBOT_IP)

q_now = rtde_r.getActualQ()
tcp_now = rtde_r.getActualTCPPose()

print("Robot's own current joint angles (rad):")
print(" ", [round(v, 4) for v in q_now])
print("Robot's own current joint angles (deg):")
print(" ", [round(np.degrees(v), 2) for v in q_now])
print()
print("Robot's own current TCP pose (getActualTCPPose, m/rad):")
print(f"  X={tcp_now[0]*1000:.2f}mm  Y={tcp_now[1]*1000:.2f}mm  Z={tcp_now[2]*1000:.2f}mm")
print(f"  RX={tcp_now[3]:.3f}  RY={tcp_now[4]:.3f}  RZ={tcp_now[5]:.3f}")
print()

lib_fk = rtde_c.getForwardKinematics(q_now)
print("ur_rtde's getForwardKinematics(same live q) result:")
print(f"  X={lib_fk[0]*1000:.2f}mm  Y={lib_fk[1]*1000:.2f}mm  Z={lib_fk[2]*1000:.2f}mm")
print()

our_pos = our_fk(q_now) * 1000
print("Our own DH-chain computation for the SAME live q:")
print(f"  X={our_pos[0]:.2f}mm  Y={our_pos[1]:.2f}mm  Z={our_pos[2]:.2f}mm")

rtde_c.disconnect()
rtde_r.disconnect()
