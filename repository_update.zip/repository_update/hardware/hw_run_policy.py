"""Execute the frozen TD3+HER / SAC+HER actors on a physical UR5e (or
URSim), closing the loop over real joint feedback via servoJ, and log
results in the exact format make_tables.py expects.

Usage:
    python3 hw_run_policy.py <td3|sac> <s1|s2|s3> [n_queries]

This is the higher-risk half of the hardware replication: the policy
was trained entirely in simulation and reacts to real sensor noise and
real dynamics it never saw during training. Read README_HARDWARE.md
sim-to-real caveats before running on a real robot, and validate
against URSim first regardless.
"""
import json
import sys
import time

import numpy as np
import torch
import torch.nn as nn

import hw_config as cfg
from env import Scene
from hw_common import (SafetyAbort, TrajectoryPoller, TrialLogger, connect,
                       full_q, print_preflight_banner, within_local_limits)

METHODS = {"td3", "sac"}


def mlp(i, o, h=128, out_act=None):
    layers = [nn.Linear(i, h), nn.ReLU(), nn.Linear(h, h), nn.ReLU(),
              nn.Linear(h, o)]
    if out_act:
        layers.append(out_act)
    return nn.Sequential(*layers)


def load_actor(algo, scene_name):
    net = mlp(6, 3, out_act=nn.Tanh()) if algo == "td3" else mlp(6, 6)
    net.load_state_dict(torch.load(f"models/{algo}_{scene_name}.pt",
                                   map_location="cpu"))
    net.eval()
    return net


@torch.no_grad()
def policy_action(algo, net, q3, g3):
    s = torch.as_tensor(np.concatenate([q3, g3])[None], dtype=torch.float32)
    if algo == "td3":
        return net(s).numpy()[0]
    mu, _ = net(s).chunk(2, -1)      # deterministic eval: policy mean only
    return torch.tanh(mu).numpy()[0]


def clip_to_limits(q3):
    return np.clip(q3, cfg.QLIM[:, 0], cfg.QLIM[:, 1])


def run(algo, scene_name, n_queries_arg):
    assert algo in METHODS
    all_queries = json.load(open("queries.json"))[scene_name]
    if isinstance(n_queries_arg, list):
        by_idx = {q["query_idx"]: q for q in all_queries}
        missing = [i for i in n_queries_arg if i not in by_idx]
        if missing:
            raise SystemExit(f"query indices not found for {scene_name}: {missing}")
        queries = [by_idx[i] for i in n_queries_arg]
    else:
        queries = all_queries[:n_queries_arg]
    scene = Scene(cfg.SCENE_BARS_XY[scene_name])
    print_preflight_banner(scene_name, f"{algo}_her", len(queries))
    print(f"servoJ: time={cfg.SERVOJ_TIME}s  lookahead={cfg.SERVOJ_LOOKAHEAD}s"
          f"  gain={cfg.SERVOJ_GAIN}  max_steps={cfg.MAX_POLICY_STEPS}")

    net = load_actor(algo, scene_name)
    rtde_c, rtde_r = connect()
    poller = TrajectoryPoller(rtde_r, hz=50.0)
    logger = TrialLogger(scene_name, f"{algo}_her")

    try:
        for q in queries:
            qi = q["query_idx"]
            qs, qg = np.array(q["q_start"]), np.array(q["q_goal"])
            print(f"\n--- query {qi} ---")

            if scene.in_collision(qs[None])[0] or scene.in_collision(qg[None])[0]:
                print(f"  query {qi}: start or goal is in collision under "
                      "the current scene model -- skipping, not moving")
                logger.log_meta(qi, False, 0.0, 0.0, False)
                continue

            t_move0 = time.perf_counter()
            rtde_c.moveJ(full_q(qs), cfg.MOVEJ_SPEED_INIT,
                        cfg.MOVEJ_ACCEL_INIT, False)
            t_reset_s = time.perf_counter() - t_move0

            poller.start()
            protective_stop, reached, timed_out = False, False, False
            t_inf_total = 0.0
            steps = 0
            try:
                q_now = np.array(rtde_r.getActualQ()[:3])
                for steps in range(1, cfg.MAX_POLICY_STEPS + 1):
                    t_period0 = time.perf_counter()

                    t_inf0 = time.perf_counter()
                    a = policy_action(algo, net, q_now, qg)
                    t_inf_total += time.perf_counter() - t_inf0

                    target = clip_to_limits(q_now + cfg.ALPHA * a)
                    q6_target = full_q(target)
                    if scene.in_collision(target[None])[0]:
                        print(f"  step {steps}: target rejected -- would "
                              "self-collide or hit a scene obstacle "
                              "-- holding position")
                        target = q_now
                        q6_target = full_q(target)
                    elif not rtde_c.isJointsWithinSafetyLimits(q6_target):
                        print(f"  step {steps}: target rejected by "
                              "controller safety check -- holding position")
                        target = q_now  # hold rather than move on rejection
                        q6_target = full_q(target)

                    rtde_c.servoJ(q6_target, 0.0, 0.0, cfg.SERVOJ_TIME,
                                 cfg.SERVOJ_LOOKAHEAD, cfg.SERVOJ_GAIN)
                    # explicit, self-contained pacing to SERVOJ_TIME: real
                    # servoJ does not block for its own `t` argument, and
                    # ur_rtde's waitPeriod() paces to the control interface's
                    # own (unrelated, unconfigured-here) frequency setting
                    # rather than to SERVOJ_TIME -- relying on it silently
                    # produced a ~10x-too-fast loop on real hardware, so we
                    # pace directly against our own clock instead
                    elapsed = time.perf_counter() - t_period0
                    remaining = cfg.SERVOJ_TIME - elapsed
                    if remaining > 0:
                        time.sleep(remaining)
                    poller.check_safe()

                    q_now = (np.array(poller.samples[-1][1][:3])
                            if poller.samples else target)
                    if np.linalg.norm(q_now - qg) <= cfg.GOAL_TOL:
                        reached = True
                        break
                else:
                    timed_out = True
                time.sleep(3.0 / 50.0)  # settle delay, see hw_run_sampling
            except SafetyAbort as e:
                print(f"  SAFETY ABORT during execution: {e}")
                protective_stop = True
            finally:
                # The servoJ segment must be ended on every exit path
                # (goal reached, step budget used up, or abort); a segment
                # left open can leave the controller's real-time script in
                # a bad state for the next motion command. Versions of this
                # script before the one released here called servoStop();
                # this version calls stopJ(), a joint-space deceleration.
                # The change was made while investigating the scene-S2
                # fault described in Section 7.7 of the paper, whose root
                # cause is not confirmed. An earlier comment in this place
                # blamed a shoulder singularity; it was withdrawn because
                # the fault did not correlate with proximity to a
                # singularity across the full set of tested queries. See
                # README_HARDWARE.md for which log was recorded with which
                # version.
                rtde_c.stopJ(2.0)
                poller.stop()

            t_exec_s = poller.samples[-1][0] if poller.samples else 0.0
            success = reached and not protective_stop

            ts = [s[0] for s in poller.samples]
            qs_full = [s[1] for s in poller.samples]
            logger.log_trajectory(qi, ts, qs_full)
            logger.log_meta(qi, success, t_inf_total * 1e3, t_exec_s,
                           protective_stop)
            print(f"  success={success}  steps={steps}  "
                  f"t_infer={t_inf_total*1e3:.1f}ms  t_exec={t_exec_s:.2f}s"
                  f"  timed_out={timed_out}")
    finally:
        rtde_c.disconnect()
        rtde_r.disconnect()
        print("\nDisconnected.")


if __name__ == "__main__":
    if len(sys.argv) < 3:
        raise SystemExit(__doc__)
    arg = sys.argv[3] if len(sys.argv) > 3 else "50"
    n = [int(x) for x in arg.split(",")] if "," in arg else int(arg)
    run(sys.argv[1], sys.argv[2], n)
