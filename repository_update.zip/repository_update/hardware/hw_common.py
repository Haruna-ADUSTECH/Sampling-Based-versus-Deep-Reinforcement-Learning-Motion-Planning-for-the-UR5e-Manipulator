"""Shared utilities for hardware replication scripts.

Every function that touches the robot is defensive: it validates joint
targets against both the local, conservative QLIM (matching the
simulation) and the controller's own isJointsWithinSafetyLimits() before
sending anything, and it checks for protective/emergency stops after
every motion. None of this has been exercised against a live controller
by the assistant that wrote it -- validate against URSim first, then a
real robot with a hand on the e-stop, per README_HARDWARE.md.
"""
import csv
import os
import sys
import threading
import time

import numpy as np

import hw_config as cfg


class SafetyAbort(Exception):
    """Raised whenever a motion is refused or a stop condition is seen."""


class TrajectoryPoller:
    """Background thread that samples getActualQ() at a fixed rate,
    independent of whether motion is being commanded via moveJ (blocking
    or asynchronous) or servoJ. This keeps trajectory-log density
    consistent across all five planners, which matters because
    roughness (R) is computed directly from consecutive logged samples
    in make_tables.py -- if sampling-based trials were logged at 50 Hz
    and policy trials at 10 Hz, the roughness comparison would be biased
    by sampling density rather than reflecting real path smoothness.

    Only this thread calls methods on the given RTDEReceiveInterface;
    the main thread reads only the plain-Python attributes below
    (protective_stop, emergency_stop, samples), which is a standard,
    safe pattern for this kind of lightweight monitoring.
    """

    def __init__(self, rtde_r, hz=50.0):
        self.rtde_r = rtde_r
        self.period = 1.0 / hz
        self.samples = []          # list of (t, q6) tuples
        self.protective_stop = False
        self.emergency_stop = False
        self._t0 = None
        self._stop_flag = threading.Event()
        self._thread = None

    def _run(self):
        while not self._stop_flag.is_set():
            t = time.perf_counter() - self._t0
            q = self.rtde_r.getActualQ()
            self.samples.append((t, list(q)))
            self.protective_stop = bool(self.rtde_r.isProtectiveStopped())
            self.emergency_stop = bool(self.rtde_r.isEmergencyStopped())
            time.sleep(self.period)

    def start(self):
        self.samples = []
        self._t0 = time.perf_counter()
        self._stop_flag.clear()
        self._thread = threading.Thread(target=self._run, daemon=True)
        self._thread.start()

    def stop(self):
        self._stop_flag.set()
        if self._thread is not None:
            self._thread.join(timeout=2.0)

    def check_safe(self):
        if self.emergency_stop:
            raise SafetyAbort("Emergency stop is active.")
        if self.protective_stop:
            raise SafetyAbort("Protective stop is active.")
        return True


def full_q(q3, wrist=None):
    """Compose a full 6-vector from the 3 simulated joints + fixed wrist."""
    wrist = cfg.WRIST_FIXED if wrist is None else wrist
    return list(np.asarray(q3, dtype=float)) + list(wrist)


def within_local_limits(q3):
    q3 = np.asarray(q3, dtype=float)
    return bool(np.all(q3 >= cfg.QLIM[:, 0]) and np.all(q3 <= cfg.QLIM[:, 1]))


def connect(require_confirmation=True):
    """Import ur_rtde and connect both interfaces. Raises a clear error
    if the library is missing rather than failing on a cryptic import
    error deep in a control loop."""
    try:
        import rtde_control
        import rtde_receive
    except ImportError as e:
        raise SystemExit(
            "ur_rtde is not installed. Install it with:\n"
            "    pip install ur_rtde\n"
            "(this requires a compiled wheel or build toolchain; see "
            "https://sdurobotics.gitlab.io/ur_rtde/installation/"
            "installation.html)\n"
            f"Original error: {e}")

    if require_confirmation:
        print("=" * 70)
        print(f"About to connect to robot/URSim at: {cfg.ROBOT_IP}")
        print("Confirm: is this the intended target, cell is clear, and")
        print("a human has a hand on the teach pendant / e-stop? [y/N]")
        print("=" * 70)
        if input("> ").strip().lower() != "y":
            raise SystemExit("Aborted by operator.")

    rtde_c = rtde_control.RTDEControlInterface(cfg.ROBOT_IP)
    rtde_r = rtde_receive.RTDEReceiveInterface(cfg.ROBOT_IP)
    if not (rtde_c.isConnected() and rtde_r.isConnected()):
        raise SafetyAbort("Failed to establish RTDE control/receive "
                          "connection -- aborting before any motion.")
    return rtde_c, rtde_r


def check_safe_to_continue(rtde_r):
    """Call frequently during any loop. Raises SafetyAbort on any stop
    condition so callers fail closed rather than continuing blindly."""
    if rtde_r.isEmergencyStopped():
        raise SafetyAbort("Emergency stop is active.")
    if rtde_r.isProtectiveStopped():
        raise SafetyAbort("Protective stop is active.")
    return True


def validate_target(rtde_c, q3):
    """Refuse to move if the target violates either the local
    conservative limits or the controller's own safety-limit check."""
    if not within_local_limits(q3):
        raise SafetyAbort(f"Target {q3} violates local QLIM {cfg.QLIM.tolist()}"
                          " -- refusing to move.")
    q6 = full_q(q3)
    if not rtde_c.isJointsWithinSafetyLimits(q6):
        raise SafetyAbort(f"Target {q6} rejected by controller's own "
                          "isJointsWithinSafetyLimits() -- refusing to move.")
    return True


class TrialLogger:
    """Writes per-timestep CSV + per-scene meta.csv in exactly the
    schema make_tables.py (from the very start of this project) already
    expects, so real hardware logs plug into the same analysis script
    used for the simulated results with zero changes."""

    def __init__(self, scene, method, log_root=None):
        self.scene, self.method = scene, method
        self.root = log_root or cfg.LOG_ROOT
        self.dir = os.path.join(self.root, scene, method)
        os.makedirs(self.dir, exist_ok=True)
        self.meta_path = os.path.join(self.dir, "meta.csv")
        if not os.path.exists(self.meta_path):
            with open(self.meta_path, "w", newline="") as f:
                csv.writer(f).writerow(
                    ["query_idx", "success", "t_plan_ms", "t_exec_s",
                     "protective_stop"])

    def log_trajectory(self, query_idx, timestamps, q_full_list):
        path = os.path.join(self.dir, f"q{query_idx}.csv")
        with open(path, "w", newline="") as f:
            w = csv.writer(f)
            w.writerow(["t", "q1", "q2", "q3", "q4", "q5", "q6"])
            for t, q in zip(timestamps, q_full_list):
                w.writerow([t] + list(q))

    def log_meta(self, query_idx, success, t_plan_ms, t_exec_s,
                 protective_stop):
        with open(self.meta_path, "a", newline="") as f:
            csv.writer(f).writerow(
                [query_idx, int(bool(success)), t_plan_ms, t_exec_s,
                 int(bool(protective_stop))])


def print_preflight_banner(scene, method, n_queries):
    print("=" * 70)
    print(f"HARDWARE TRIAL: scene={scene}  method={method}  "
          f"n_queries={n_queries}")
    print(f"Robot IP: {cfg.ROBOT_IP}")
    print(f"Local joint limits (joints 1-3): {cfg.QLIM.tolist()}")
    print(f"Fixed wrist pose (joints 4-6):   {cfg.WRIST_FIXED}")
    print("Logs will be written under: "
          f"{os.path.join(cfg.LOG_ROOT, scene, method)}")
    print("=" * 70)
