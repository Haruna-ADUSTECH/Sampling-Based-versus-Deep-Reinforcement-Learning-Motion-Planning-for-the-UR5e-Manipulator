"""A deliberately simple stand-in for ur_rtde, used ONLY to dry-run the
control-flow logic in hw_run_sampling.py / hw_run_policy.py without any
real hardware. It simulates a robot that moves toward commanded targets
with first-order dynamics and never faults, so it exercises every code
path (connect, validate, move, servo, poll, log, disconnect) but proves
nothing about real timing, safety behaviour, or physical dynamics.
Install this on sys.path ahead of the real package to dry-run; remove
it / do not ship it for real hardware use.
"""
import time
import numpy as np


class _Shared:
    q = np.array([0.0, -1.57, 1.0, 0.0, -1.5708, 0.0])
    connected = True
    protective_stop = False
    emergency_stop = False


class RTDEControlInterface:
    def __init__(self, ip):
        self.ip = ip

    def isConnected(self):
        return _Shared.connected

    def isJointsWithinSafetyLimits(self, q6):
        return all(-6.28 <= v <= 6.28 for v in q6)

    def isProgramRunning(self):
        return True

    def moveJ(self, q6, speed, accel, asynchronous=False):
        steps = 5
        start = _Shared.q.copy()
        target = np.array(q6)
        for i in range(1, steps + 1):
            _Shared.q = start + (target - start) * i / steps
            time.sleep(0.01)
        return True

    def servoJ(self, q6, speed, accel, t, lookahead, gain):
        target = np.array(q6)
        _Shared.q = _Shared.q + (target - _Shared.q) * 0.6
        time.sleep(t)
        return True

    def stopJ(self, a=2.0, asynchronous=False):
        return True

    def servoStop(self, a=10.0):
        return True

    def disconnect(self):
        pass


class RTDEReceiveInterface:
    def __init__(self, ip):
        self.ip = ip

    def isConnected(self):
        return _Shared.connected

    def getActualQ(self):
        return list(_Shared.q)

    def isProtectiveStopped(self):
        return _Shared.protective_stop

    def isEmergencyStopped(self):
        return _Shared.emergency_stop

    def getRobotMode(self):
        return 7  # ROBOT_MODE_RUNNING

    def disconnect(self):
        pass
