"""Mock rtde_receive module -- re-exports the RTDEReceiveInterface
defined in the sibling mock rtde_control module, purely so
`import rtde_receive; rtde_receive.RTDEReceiveInterface(...)` works the
same way real ur_rtde's split-module layout does."""
from rtde_control import RTDEReceiveInterface
