"""Clean a hardware meta.csv: drop pre-fix failure rows, keep only the
LAST (most recent) row per unique query_idx among successes, so each
method contributes exactly one row per query -- a fair, deduplicated
comparison, and transparent about exactly what was removed."""
import sys
import pandas as pd

path = sys.argv[1]
df = pd.read_csv(path)
print(f"Read {len(df)} total rows from {path}")

n_fail = (df["success"] == 0).sum()
print(f"Dropping {n_fail} row(s) with success=0 (pre-fix failures):")
print(df[df["success"] == 0].to_string(index=False))

ok = df[df["success"] == 1].copy()
dup_counts = ok["query_idx"].value_counts().sort_index()
print(f"\nPost-fix success rows per query_idx (before dedup):")
print(dup_counts.to_string())

# keep the LAST occurrence of each query_idx (most recent successful run)
clean = ok.drop_duplicates(subset="query_idx", keep="last").sort_values("query_idx")
print(f"\nAfter keeping last-occurrence-per-query: {len(clean)} rows")
print(clean.to_string(index=False))

backup = path.replace(".csv", "_RAW_BACKUP.csv")
df.to_csv(backup, index=False)
clean.to_csv(path, index=False)
print(f"\nOriginal (all 19 rows) backed up to: {backup}")
print(f"Clean, deduplicated file written to: {path}")
