# Sampling-based versus deep reinforcement learning motion planning for the UR5e

Code, queries, trained policies, results and hardware logs behind the paper "Sampling-Based versus Deep Reinforcement Learning Motion Planning for the UR5e Manipulator: A Controlled Simulation Benchmark with Preliminary Hardware Validation". The study compares PRM, PRM with shortcutting (PRM+SC), RRT-Connect, TD3+HER and SAC+HER on the three-joint positioning subspace of a UR5e, in three scenes with 50 frozen queries each, and checks the result on a real UR5e.

## Layout

| Path | Content |
|---|---|
| `env.py`, `planners.py`, `agents.py`, `train.py`, `evaluate.py` | The simulation study. `env.py` is the original bare-arm collision model |
| `models/` | The six trained policies of the study. These are the policies that were run on the robot |
| `results.json`, `summary.json`, `logs/` | Results of the original benchmark (Table 3 of the paper) |
| `additional_analysis/` | The benchmark rerun under the gripper-aware collision model, the statistical tests and the query checks (Sections 6.3, 7.1 and 7.2). See `additional_analysis/README.md` |
| `hardware/` | Scripts, raw 50 Hz logs, deployed policies and analysis of the UR5e trials (Section 7). Start with `hardware/README_HARDWARE.md` |
| `fig_*.pdf`, `*_fig.py`, `paper_*.tex`, `fill_paper.py`, `README.txt` | Files of the earlier conference version of the paper |

## Reproducing the original benchmark

```
python3 train.py td3 s1 3000 0        # repeat for {td3, sac} x {s1, s2, s3}
python3 evaluate.py                    # writes results.json, summary.json and the figures
```

Requirements: Python 3 with numpy, scipy, pandas, matplotlib and PyTorch.

## What to keep in mind

The original benchmark uses a collision model of the bare arm. The hardware work added the gripper to the model. Under that model, 120 of the 150 original queries are invalid, and the policies were trained without the gripper. Section 7 of the paper reports what this means, repeats the benchmark under the gripper-aware model (`additional_analysis/gripper_aware_rerun/`), and reports the hardware trials. `hardware/queries.json` holds the queries used on the robot and `hardware/queries_original_bare_arm.json` the original ones.

## Data availability

Everything needed to check the numbers of the paper is in this repository: simulation code, evaluation scripts, query sets, trained policies, simulated results, the deployment scripts, the raw hardware logs and the analysis scripts. A file with checksums is in `CHECKSUMS.sha256`.
