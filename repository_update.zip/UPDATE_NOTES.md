# Repository update for the hardware section

`repository_update/` holds the files to add to your GitHub repository. Copy its contents over your local clone (folders merge, files with the same name are replaced), then check, commit and push:

```
sha256sum -c CHECKSUMS.sha256        # run in the repository root, every line should say OK
git add hardware additional_analysis README.md .gitignore CHECKSUMS.sha256
git commit -m "Add hardware logs, scripts and analysis"
git push
```

## Remove these first, if they are in your clone

- `additional_analysis/corrected_model_rerun/`, from the earlier additional_analysis package. It used a collision model that is not the one on the robot. `additional_analysis/gripper_aware_rerun/` replaces it.
- `hardware/venv/`, if it was ever committed. It holds about 330 MB of Python packages and is not part of the record. `.gitignore` keeps it out from now on. If it is already tracked, run `git rm -r --cached hardware/venv`.
- The old root `README.txt` describes the conference version, and its hardware section says nothing was run on a real controller. `README.md` replaces it.

## What changed in your files

- `hardware/README_HARDWARE.md` was replaced. The old one said that the code had never been run on a real controller (original SHA-256 `0eca1334ae3789c6f188977630668eae243b07805c92be970c43a8d3d4dc9912`).
- `hardware/hw_run_policy.py`: only the comment block above `rtde_c.stopJ(2.0)` changed. It named a shoulder singularity as the confirmed cause of the S2 fault, and the paper withdraws that. No code line changed. Original SHA-256 `07a542c77e38e08820071e76e178ad635b463e442a039713d7631ecc35d57c31`.
- Everything else in `hardware/` (scripts, `hw_logs/`, `models/`, `queries.json`, `env.py`, `planners.py`) is exactly as you sent it. Only `hardware/venv/` and the `__pycache__` folders were left out.
- New: `hardware/queries_original_bare_arm.json`, `hardware/analysis/`, `additional_analysis/` (rerun under your hardware model, scripts, results), the root `README.md`, `.gitignore` and `CHECKSUMS.sha256`.

## Checks that were run

Every script in `hardware/analysis/` and `additional_analysis/analysis_scripts/` was run from a clean copy of your repository with this update on top. The outputs are byte-identical to the shipped ones, and they reproduce the numbers in the paper (hardware tables, the 24 of 37 learned-planner trials, the 34 of 37 agreement with the gated simulation, 120 of 150 invalid original queries, the rerun table, the statistical tests).

## Please confirm

1. **Row selection for SAC+HER on scene S1.** `meta.csv` has 26 rows and no run labels. I reconstructed the 10 reported rows (9, 10, 14, 15, 16 and 22 to 26) from the row order, the execution times and your terminal output. `hardware/README_HARDWARE.md`, Section 5.2, lists every row with the reason. The count of 6 successes in 10 does not change if the first pass over queries 5 to 9 is used instead of the second.
2. **Script versions.** The S1 and S3 learned-policy trials were recorded before the last edit of `hw_run_policy.py`, so they used the `servoStop` version and not the `stopJ` file you sent. The S1 sampling-based runs were recorded before the last edit of `hw_run_sampling.py`. Both older versions are missing from your package. Section 4 of the README says this plainly. If you still have them, add them under `hardware/older_versions/`.
3. **Paper placeholders.** The Funding statement still has a place for a grant number, and the Author contributions entry is a template.
4. **Data availability.** The statement in the paper is true only once this update is public. A Zenodo archive of the repository would give you a DOI to cite next to the GitHub address.
