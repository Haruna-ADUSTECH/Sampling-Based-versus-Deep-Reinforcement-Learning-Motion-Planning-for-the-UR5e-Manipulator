"""PRM (+ shortcutting) and RRT-Connect over the capsule environment."""
import heapq
import time
import numpy as np
from scipy.spatial import cKDTree


class PRM:
    def __init__(self, scene, n_nodes=1500, k=12, seed=0, step=0.06):
        self.scene, self.k, self.step = scene, k, step
        rng = np.random.default_rng(seed)
        t0 = time.perf_counter()
        self.V = scene.sample_free(rng, n_nodes)
        self.tree = cKDTree(self.V)
        self.adj = [[] for _ in range(n_nodes)]
        _, idx = self.tree.query(self.V, k=k + 1)
        seen = set()
        for i in range(n_nodes):
            for j in idx[i, 1:]:
                key = (min(i, j), max(i, j))
                if key in seen:
                    continue
                seen.add(key)
                if scene.edge_free(self.V[i], self.V[j], step):
                    w = float(np.linalg.norm(self.V[i] - self.V[j]))
                    self.adj[i].append((j, w))
                    self.adj[j].append((i, w))
        self.build_time = time.perf_counter() - t0

    def _astar(self, adj, start, goal, pos):
        h = lambda i: np.linalg.norm(pos[i] - pos[goal])
        g = {start: 0.0}
        came = {}
        pq = [(h(start), start)]
        closed = set()
        while pq:
            _, u = heapq.heappop(pq)
            if u == goal:
                path = [u]
                while u in came:
                    u = came[u]
                    path.append(u)
                return path[::-1]
            if u in closed:
                continue
            closed.add(u)
            for v, w in adj[u]:
                ng = g[u] + w
                if ng < g.get(v, np.inf):
                    g[v] = ng
                    came[v] = u
                    heapq.heappush(pq, (ng + h(v), v))
        return None

    def query(self, qs, qg):
        """Returns (waypoints or None, query_time_s)."""
        t0 = time.perf_counter()
        pos = np.vstack([self.V, qs, qg])
        i_s, i_g = len(self.V), len(self.V) + 1
        adj = [list(a) for a in self.adj] + [[], []]
        _, idx = self.tree.query([qs, qg], k=self.k)
        for node, nbrs in ((i_s, idx[0]), (i_g, idx[1])):
            for j in nbrs:
                if self.scene.edge_free(pos[node], self.V[j], self.step):
                    w = float(np.linalg.norm(pos[node] - self.V[j]))
                    adj[node].append((j, w))
                    adj[j].append((node, w))
        path = self._astar(adj, i_s, i_g, pos)
        dt = time.perf_counter() - t0
        if path is None:
            return None, dt
        return pos[path], dt

    def shortcut(self, W, iters=120, seed=0):
        """Random-pair shortcutting; returns (waypoints, extra_time_s)."""
        t0 = time.perf_counter()
        rng = np.random.default_rng(seed)
        W = [w.copy() for w in W]
        for _ in range(iters):
            if len(W) < 3:
                break
            i, j = sorted(rng.choice(len(W), 2, replace=False))
            if j - i < 2:
                continue
            if self.scene.edge_free(W[i], W[j], self.step):
                W = W[: i + 1] + W[j:]
        return np.array(W), time.perf_counter() - t0


class RRTConnect:
    def __init__(self, scene, step=0.20, max_iters=4000, seed=0,
                 col_step=0.06):
        self.scene, self.step, self.max_iters = scene, step, max_iters
        self.col_step = col_step
        self.rng = np.random.default_rng(seed)

    def _extend(self, tree, parents, q_rand):
        d = np.linalg.norm(np.array(tree) - q_rand, axis=1)
        i = int(np.argmin(d))
        q_near = tree[i]
        v = q_rand - q_near
        n = np.linalg.norm(v)
        q_new = q_rand if n <= self.step else q_near + self.step * v / n
        if self.scene.edge_free(q_near, q_new, self.col_step):
            tree.append(q_new)
            parents.append(i)
            return len(tree) - 1, np.allclose(q_new, q_rand)
        return None, False

    def plan(self, qs, qg):
        from env import QLIM
        t0 = time.perf_counter()
        Ta, Pa = [qs.copy()], [-1]
        Tb, Pb = [qg.copy()], [-1]
        for _ in range(self.max_iters):
            q_rand = self.rng.uniform(QLIM[:, 0], QLIM[:, 1])
            ia, _ = self._extend(Ta, Pa, q_rand)
            if ia is not None:
                # connect the other tree towards the new node
                while True:
                    ib, reached = self._extend(Tb, Pb, Ta[ia])
                    if ib is None:
                        break
                    if reached:
                        pa = [ia]
                        while Pa[pa[-1]] != -1:
                            pa.append(Pa[pa[-1]])
                        pb = [ib]
                        while Pb[pb[-1]] != -1:
                            pb.append(Pb[pb[-1]])
                        A = [Ta[i] for i in pa[::-1]]
                        B = [Tb[i] for i in pb]
                        W = np.array(A + B)
                        if not np.allclose(W[0], qs):
                            W = W[::-1]
                        return W, time.perf_counter() - t0
            Ta, Pa, Tb, Pb = Tb, Pb, Ta, Pa
        return None, time.perf_counter() - t0
