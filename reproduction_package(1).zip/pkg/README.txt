HOW TO COMPILE THE PAPER
=========================

If you only want the paper in Overleaf:
  1. Start a NEW blank Overleaf project (do not reuse a project that
     still has old files in it).
  2. Upload exactly these four files:
       - paper_FINAL_compile_this_one.tex
       - fig_architecture.pdf
       - fig_scenes.pdf
       - fig_box.pdf
  3. In Overleaf, rename paper_FINAL_compile_this_one.tex to main.tex
     (Overleaf auto-compiles whatever is named main.tex; this avoids
     any ambiguity about which file is the root document).
  4. Compile. It uses the standard IEEEtran class that Overleaf already
     ships with -- no extra class files or packages need to be uploaded.
     Expect 4 pages, zero errors, a few harmless "underfull hbox"
     notices only.

PAPER STRUCTURE
================
  I.    Introduction
  II.   Compared Planning Methods       (PRM/PRM+SC/RRT-Connect, TD3+HER/SAC+HER)
  III.  System Architecture             (Fig. 1: pipeline block diagram)
  IV.   Experimental Setup              (platform/scenes text; protocol; metrics)
  V.    Results                         (Fig. 2: scenes+paths, Table I, Fig. 3: box plots)
  VI.   Discussion                      (immediately follows Results, incl. limitations)
  VII.  Conclusion
  References                            (22 entries, all cited in text)

Both result figures (Fig. 2, Fig. 3) live under Section V (Results),
which is immediately followed by Section VI (Discussion), per the
requested figure placement. Fig. 1 (system architecture) sits in its own
Section III, ahead of the experimental protocol.

WHAT WENT WRONG LAST TIME (kept for reference)
================================================
This package also includes paper_template_UNFILLED.tex. That file is
NOT a paper -- it is a skeleton full of <<PLACEHOLDER>> tokens (e.g.
<<ABSTRACT_RESULT>>, <<TABLE_ROWS>>) that only becomes the real paper
after fill_paper.py substitutes measured numbers into every token.

If paper_template_UNFILLED.tex gets uploaded to Overleaf alongside the
real paper, Overleaf's auto-detection can pick it as the "main"
document instead of the real one. Compiling it directly fails
immediately: the underscore inside token names is read as a math
subscript outside math mode ("Missing $ inserted"), and the empty
<<TABLE_ROWS>> placeholder leaves a \midrule sitting mid-row inside the
results table ("Misplaced \noalign" and a cascade of alignment errors).
Keep paper_template_UNFILLED.tex out of any Overleaf project; it's
included here only so the experiment can be rerun end to end.

REGENERATING THE PAPER FROM SCRATCH (optional)
================================================
  python3 train.py td3 s1 3000 0        # repeat for {td3,sac} x {s1,s2,s3}
  python3 evaluate.py                    # writes results.json, summary.json,
                                          # fig_scenes.pdf, fig_box.pdf
  python3 architecture_fig.py            # writes fig_architecture.pdf
  python3 fill_paper.py                  # writes a fully-filled main.tex
                                          # from paper_template_UNFILLED.tex
  pdflatex main.tex && pdflatex main.tex # two passes for refs/citations

If you edit paper_template_UNFILLED.tex (e.g. to add citations or
restructure sections again), re-run fill_paper.py afterward so
paper_FINAL_compile_this_one.tex stays in sync -- don't hand-edit the
filled file directly or the two will drift apart.
