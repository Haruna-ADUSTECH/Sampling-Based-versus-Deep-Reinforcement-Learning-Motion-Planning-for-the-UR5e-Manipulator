"""Train one agent on one scene.
Usage: python train.py <td3|sac> <s1|s2|s3> <episodes> <seed>"""
import json
import sys
import time
import numpy as np
import torch
from env import RAMDP, SCENES
from agents import TD3, SAC, HERBuffer

algo, scene_name = sys.argv[1], sys.argv[2]
episodes = int(sys.argv[3]) if len(sys.argv) > 3 else 2000
seed = int(sys.argv[4]) if len(sys.argv) > 4 else 0

np.random.seed(seed)
torch.manual_seed(seed)
env = RAMDP(SCENES[scene_name], seed=seed)
agent = TD3() if algo == "td3" else SAC()
buf = HERBuffer(3, 3, tol=env.TOL)

WARMUP_EP = 25
UPDATE_EVERY = 2
succ_hist = []
t0 = time.perf_counter()
steps = 0
for ep in range(episodes):
    q, g = env.reset()
    buf.goal = g
    qs, acts = [q], []
    done = False
    reached = False
    while not done:
        if ep < WARMUP_EP:
            a = np.random.uniform(-1, 1, 3)
        else:
            a = agent.act(q, g, noise=0.2)
        q, r, done, reached = env.step(a)
        qs.append(q)
        acts.append(a)
        steps += 1
        if ep >= WARMUP_EP and steps % UPDATE_EVERY == 0:
            agent.update(buf)
    buf.store_episode(qs, acts)
    succ_hist.append(1.0 if reached else 0.0)
    if (ep + 1) % 100 == 0:
        print(f"[{algo}-{scene_name}] ep {ep+1}/{episodes} "
              f"succ(last100)={np.mean(succ_hist[-100:]):.2f} "
              f"t={time.perf_counter()-t0:.0f}s", flush=True)

train_time = time.perf_counter() - t0
net = agent.actor if algo == "td3" else agent.pi
torch.save(net.state_dict(), f"models/{algo}_{scene_name}.pt")
json.dump({"algo": algo, "scene": scene_name, "episodes": episodes,
           "train_time_s": train_time,
           "final_success": float(np.mean(succ_hist[-200:]))},
          open(f"models/{algo}_{scene_name}.json", "w"))
print(f"DONE {algo}-{scene_name} {train_time:.0f}s "
      f"final_succ={np.mean(succ_hist[-200:]):.2f}", flush=True)
