"""Evaluate PRM, PRM+SC, RRT-Connect, TD3+HER, SAC+HER on identical
frozen queries per scene. Writes results.json, LaTeX table rows, and
figures (fig_scenes.pdf, fig_box.pdf)."""
import json
import time
import numpy as np
import torch
import torch.nn as nn
from scipy.stats import wilcoxon
from env import RAMDP, SCENES, fk_points, QLIM
from planners import PRM, RRTConnect
from agents import mlp

N_QUERIES = 50
V_MAX = 1.05          # rad/s executed joint speed for t_exec estimate
DS = 0.05             # resampling step for roughness
MAX_POLICY_STEPS = 120
METHODS = ["prm", "prm_sc", "rrt", "td3", "sac"]
LABELS = {"prm": "PRM", "prm_sc": "PRM + SC", "rrt": "RRT-Connect",
          "td3": "TD3+HER", "sac": "SAC+HER"}


# ---------- metrics ----------
def path_length(W):
    return float(np.sum(np.linalg.norm(np.diff(W, axis=0), axis=1)))


def resample(W, ds=DS):
    seg = np.linalg.norm(np.diff(W, axis=0), axis=1)
    s = np.concatenate([[0], np.cumsum(seg)])
    if s[-1] < 1e-9:
        return W
    su = np.arange(0, s[-1], ds)
    return np.vstack([np.interp(su, s, W[:, j]) for j in range(3)]).T


def roughness(W):
    Wr = resample(W)
    if len(Wr) < 4:
        return 0.0
    qdd = np.diff(Wr, n=2, axis=0)
    return float(np.mean(np.sum(qdd ** 2, axis=1)))


def exec_time(W):
    return float(np.sum(np.max(np.abs(np.diff(W, axis=0)), axis=1)) / V_MAX)


# ---------- learned-policy rollout ----------
def load_actor(algo, scene):
    if algo == "td3":
        net = mlp(6, 3, out_act=nn.Tanh())
    else:
        net = mlp(6, 6)
    net.load_state_dict(torch.load(f"models/{algo}_{scene}.pt"))
    net.eval()
    return net


@torch.no_grad()
def policy_action(algo, net, q, g):
    s = torch.as_tensor(np.concatenate([q, g])[None], dtype=torch.float32)
    if algo == "td3":
        return net(s).numpy()[0]
    mu, _ = net(s).chunk(2, -1)
    return torch.tanh(mu).numpy()[0]


def rollout(algo, net, env, qs, qg):
    q, g = env.reset(q0=qs.copy(), g=qg.copy())
    W = [q.copy()]
    t_inf = 0.0
    reached = False
    for _ in range(MAX_POLICY_STEPS):
        t0 = time.perf_counter()
        a = policy_action(algo, net, q, g)
        t_inf += time.perf_counter() - t0
        q, r, done, reached = env.step(a)
        W.append(q.copy())
        if reached:
            break
        if len(W) > 12 and np.linalg.norm(W[-1] - W[-12]) < 1e-4:
            break  # stuck
    return np.array(W), reached, t_inf


# ---------- main ----------
results = {m: [] for m in METHODS}
offline = {}
scene_queries = {}
rng = np.random.default_rng(42)

for scene_name, scene in SCENES.items():
    print(f"=== scene {scene_name} ===", flush=True)
    env = RAMDP(scene, seed=100)
    # frozen queries
    queries = []
    while len(queries) < N_QUERIES:
        qs, qg = scene.sample_free(rng, 2)
        if np.linalg.norm(qs - qg) > 1.2:
            queries.append((qs, qg))
    scene_queries[scene_name] = queries

    prm = PRM(scene, n_nodes=1500, k=12, seed=7)
    offline[f"prm_build_{scene_name}"] = prm.build_time
    rrt = RRTConnect(scene, seed=7)
    nets = {a: load_actor(a, scene_name) for a in ("td3", "sac")}

    for qi, (qs, qg) in enumerate(queries):
        # PRM / PRM+SC
        W, tq = prm.query(qs, qg)
        if W is None:
            for m in ("prm", "prm_sc"):
                results[m].append(dict(scene=scene_name, query=qi,
                                       success=False, t_plan=tq * 1e3))
        else:
            results["prm"].append(dict(
                scene=scene_name, query=qi, success=True, L=path_length(W),
                R=roughness(W), t_plan=tq * 1e3, t_exec=exec_time(W)))
            Wsc, tsc = prm.shortcut(list(W), iters=120, seed=qi)
            results["prm_sc"].append(dict(
                scene=scene_name, query=qi, success=True,
                L=path_length(Wsc), R=roughness(Wsc),
                t_plan=(tq + tsc) * 1e3, t_exec=exec_time(Wsc)))
            if scene_name == "s2" and qi == 0:
                np.save("example_prm.npy", Wsc)
        # RRT-Connect
        W, tq = rrt.plan(qs, qg)
        if W is None:
            results["rrt"].append(dict(scene=scene_name, query=qi,
                                       success=False, t_plan=tq * 1e3))
        else:
            results["rrt"].append(dict(
                scene=scene_name, query=qi, success=True, L=path_length(W),
                R=roughness(W), t_plan=tq * 1e3, t_exec=exec_time(W)))
        # learned policies
        for algo in ("td3", "sac"):
            W, ok, t_inf = rollout(algo, nets[algo], env, qs, qg)
            rec = dict(scene=scene_name, query=qi, success=bool(ok),
                       t_plan=t_inf * 1e3)
            if ok:
                rec.update(L=path_length(W), R=roughness(W),
                           t_exec=exec_time(W))
                if scene_name == "s2" and qi == 0 and algo == "sac":
                    np.save("example_sac.npy", W)
            results[algo].append(rec)
    print(f"scene {scene_name} done", flush=True)

# training metadata
for a in ("td3", "sac"):
    tt = 0.0
    for s in SCENES:
        tt += json.load(open(f"models/{a}_{s}.json"))["train_time_s"]
    offline[f"{a}_train_total_s"] = tt

json.dump({"results": results, "offline": offline},
          open("results.json", "w"), default=float)

# ---------- tables ----------
import pandas as pd
dfs = {m: pd.DataFrame(results[m]) for m in METHODS}
print("\n% ---- Table I rows (all scenes pooled) ----")
rows = {}
for m in METHODS:
    d = dfs[m]
    ok = d[d.success]
    rows[m] = dict(
        succ=100 * d.success.mean(), L=ok.L.mean(), Ls=ok.L.std(),
        R=100 * ok.R.mean(), Rs=100 * ok.R.std(),
        tp=ok.t_plan.mean(), te=ok.t_exec.mean(), tes=ok.t_exec.std())
    r = rows[m]
    print(f"{LABELS[m]:<12}& {r['succ']:.1f} & {r['L']:.2f} $\\pm$ "
          f"{r['Ls']:.2f} & {r['R']:.2f} $\\pm$ {r['Rs']:.2f} & "
          f"{r['tp']:.1f} & {r['te']:.2f} $\\pm$ {r['tes']:.2f}\\\\")

print("\n% ---- per-scene success and mean L ----")
for s in SCENES:
    line = [s]
    for m in METHODS:
        d = dfs[m][dfs[m].scene == s]
        ok = d[d.success]
        line.append(f"{m}: succ={100*d.success.mean():.0f}% "
                    f"L={ok.L.mean():.2f}")
    print(" | ".join(line))

print("\n% ---- Wilcoxon vs PRM+SC on L (paired, both-success) ----")
b = dfs["prm_sc"].set_index(["scene", "query"])
wtests = {}
for m in METHODS:
    if m == "prm_sc":
        continue
    x = dfs[m].set_index(["scene", "query"])
    j = b.join(x, lsuffix="_b", rsuffix="_m")
    j = j[(j.success_b) & (j.success_m)].dropna(subset=["L_b", "L_m"])
    if len(j) >= 10:
        W, p = wilcoxon(j.L_b, j.L_m)
        d = 100 * (j.L_m.mean() - j.L_b.mean()) / j.L_b.mean()
        wtests[m] = dict(n=len(j), dpct=d, W=float(W), p=float(p))
        print(f"{LABELS[m]:<12} n={len(j)} dL={d:+.1f}% W={W:.0f} p={p:.2e}")
json.dump({"rows": rows, "wilcoxon": wtests, "offline": offline},
          open("summary.json", "w"), default=float)

# ---------- figures ----------
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
plt.rcParams.update({"font.size": 8})

# fig 1: the three scenes + example EE paths in s2
fig = plt.figure(figsize=(7.0, 2.3))
for si, (sname, scene) in enumerate(SCENES.items()):
    ax = fig.add_subplot(1, 3, si + 1, projection="3d")
    th = np.linspace(0, 2 * np.pi, 16)
    for (bx, by) in scene.bars:
        for zz in np.linspace(0, 0.9, 8):
            ax.plot(bx + 0.05 * np.cos(th), by + 0.05 * np.sin(th), zz,
                    color="0.35", lw=0.6)
    q0 = scene.sample_free(np.random.default_rng(3), 1)[0]
    p1, p2, p3 = (p[0] for p in fk_points(q0[None]))
    ax.plot(*zip([0, 0, 0], p1, p2, p3), "o-", color="tab:orange",
            lw=3, ms=3)
    if sname == "s2":
        for f, c, lab in (("example_prm.npy", "tab:red", "PRM+SC"),
                          ("example_sac.npy", "tab:green", "SAC+HER")):
            try:
                W = np.load(f)
                _, _, ee = fk_points(W)
                ax.plot(ee[:, 0], ee[:, 1], ee[:, 2], c=c, lw=1.4,
                        label=lab)
            except FileNotFoundError:
                pass
        ax.legend(loc="upper left", fontsize=6)
    ax.set_title(sname.upper(), fontsize=8)
    ax.set_xlim(-0.8, 0.8); ax.set_ylim(-0.8, 0.8); ax.set_zlim(0, 1.0)
    ax.tick_params(labelsize=5, pad=-2)
fig.tight_layout()
fig.savefig("fig_scenes.pdf", bbox_inches="tight")

# fig 2: box plots of path length per scene per method
fig, axes = plt.subplots(1, 3, figsize=(7.0, 1.9), sharey=True)
for si, sname in enumerate(SCENES):
    data, labs = [], []
    for m in METHODS:
        d = dfs[m]
        ok = d[(d.scene == sname) & (d.success)]
        data.append(ok.L.dropna().values)
        labs.append(LABELS[m])
    bp = axes[si].boxplot(data, tick_labels=labs, showfliers=False,
                          widths=0.6)
    axes[si].set_title(sname.upper(), fontsize=8)
    axes[si].tick_params(axis="x", rotation=35, labelsize=6)
axes[0].set_ylabel("path length $L$ [rad]")
fig.tight_layout()
fig.savefig("fig_box.pdf", bbox_inches="tight")
print("\nfigures written", flush=True)
