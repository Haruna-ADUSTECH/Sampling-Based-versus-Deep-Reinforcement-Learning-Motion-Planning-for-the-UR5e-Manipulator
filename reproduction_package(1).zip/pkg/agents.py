"""TD3+HER and SAC+HER agents (goal-conditioned, continuous actions).
Hyper-parameters follow Fujimoto et al. (2018) / Haarnoja et al. (2018)
with HER 'future' relabelling (Andrychowicz et al., 2017)."""
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F

torch.set_num_threads(1)
DEV = "cpu"


def mlp(i, o, h=128, out_act=None):
    layers = [nn.Linear(i, h), nn.ReLU(), nn.Linear(h, h), nn.ReLU(),
              nn.Linear(h, o)]
    if out_act:
        layers.append(out_act)
    return nn.Sequential(*layers)


class HERBuffer:
    """Episode-wise buffer with 'future' goal relabelling (k=4)."""

    def __init__(self, sdim, adim, tol, size=300_000, k=4):
        self.k, self.tol = k, tol
        self.q = np.zeros((size, sdim), np.float32)
        self.a = np.zeros((size, adim), np.float32)
        self.q2 = np.zeros((size, sdim), np.float32)
        self.g = np.zeros((size, sdim), np.float32)
        self.fut = np.zeros((size, sdim), np.float32)  # random future state
        self.n, self.ptr, self.size = 0, 0, size

    def store_episode(self, qs, acts):
        """qs: list len T+1 of states; acts: list len T of actions."""
        T = len(acts)
        rng = np.random.default_rng()
        for t in range(T):
            fut_idx = rng.integers(t + 1, T + 1)
            i = self.ptr
            self.q[i], self.a[i], self.q2[i] = qs[t], acts[t], qs[t + 1]
            self.g[i] = self.goal
            self.fut[i] = qs[fut_idx]
            self.ptr = (self.ptr + 1) % self.size
            self.n = min(self.n + 1, self.size)

    def sample(self, batch):
        idx = np.random.randint(0, self.n, batch)
        # with prob k/(k+1) substitute the future achieved state as goal
        her = np.random.random(batch) < self.k / (self.k + 1)
        g = np.where(her[:, None], self.fut[idx], self.g[idx])
        d = np.linalg.norm(self.q2[idx] - g, axis=1)
        r = np.where(d <= self.tol, 0.0, -1.0).astype(np.float32)
        done = (d <= self.tol).astype(np.float32)
        t = lambda x: torch.as_tensor(x, device=DEV)
        s = t(np.concatenate([self.q[idx], g], 1).astype(np.float32))
        s2 = t(np.concatenate([self.q2[idx], g], 1).astype(np.float32))
        return s, t(self.a[idx]), t(r), s2, t(done)


class TD3:
    def __init__(self, sdim=3, adim=3, gamma=0.98, tau=0.005, lr=1e-3):
        self.gamma, self.tau, self.adim = gamma, tau, adim
        d = 2 * sdim
        self.actor = mlp(d, adim, out_act=nn.Tanh())
        self.actor_t = mlp(d, adim, out_act=nn.Tanh())
        self.q1, self.q2 = mlp(d + adim, 1), mlp(d + adim, 1)
        self.q1_t, self.q2_t = mlp(d + adim, 1), mlp(d + adim, 1)
        for t, s in ((self.actor_t, self.actor), (self.q1_t, self.q1),
                     (self.q2_t, self.q2)):
            t.load_state_dict(s.state_dict())
        self.opt_a = torch.optim.Adam(self.actor.parameters(), lr)
        self.opt_c = torch.optim.Adam(
            list(self.q1.parameters()) + list(self.q2.parameters()), lr)
        self.it = 0

    @torch.no_grad()
    def act(self, q, g, noise=0.2):
        s = torch.as_tensor(np.concatenate([q, g])[None], dtype=torch.float32)
        a = self.actor(s).numpy()[0]
        if noise > 0:
            a = np.clip(a + np.random.normal(0, noise, self.adim), -1, 1)
        return a

    def update(self, buf, batch=128, policy_delay=2):
        s, a, r, s2, done = buf.sample(batch)
        with torch.no_grad():
            eps = (0.2 * torch.randn_like(a)).clamp(-0.5, 0.5)
            a2 = (self.actor_t(s2) + eps).clamp(-1, 1)
            qt = torch.min(self.q1_t(torch.cat([s2, a2], 1)),
                           self.q2_t(torch.cat([s2, a2], 1))).squeeze(-1)
            y = r + self.gamma * (1 - done) * qt
        sa = torch.cat([s, a], 1)
        lc = F.mse_loss(self.q1(sa).squeeze(-1), y) + \
            F.mse_loss(self.q2(sa).squeeze(-1), y)
        self.opt_c.zero_grad(); lc.backward(); self.opt_c.step()
        self.it += 1
        if self.it % policy_delay == 0:
            la = -self.q1(torch.cat([s, self.actor(s)], 1)).mean()
            self.opt_a.zero_grad(); la.backward(); self.opt_a.step()
            with torch.no_grad():
                for t, src in ((self.actor_t, self.actor),
                               (self.q1_t, self.q1), (self.q2_t, self.q2)):
                    for pt, ps in zip(t.parameters(), src.parameters()):
                        pt.mul_(1 - self.tau).add_(self.tau * ps)


class SAC:
    LOG_STD_MIN, LOG_STD_MAX = -20, 2

    def __init__(self, sdim=3, adim=3, gamma=0.98, tau=0.005, lr=1e-3,
                 alpha=0.2):
        self.gamma, self.tau, self.alpha, self.adim = gamma, tau, alpha, adim
        d = 2 * sdim
        self.pi = mlp(d, 2 * adim)
        self.q1, self.q2 = mlp(d + adim, 1), mlp(d + adim, 1)
        self.q1_t, self.q2_t = mlp(d + adim, 1), mlp(d + adim, 1)
        self.q1_t.load_state_dict(self.q1.state_dict())
        self.q2_t.load_state_dict(self.q2.state_dict())
        self.opt_pi = torch.optim.Adam(self.pi.parameters(), lr)
        self.opt_c = torch.optim.Adam(
            list(self.q1.parameters()) + list(self.q2.parameters()), lr)

    def _dist(self, s):
        mu, log_std = self.pi(s).chunk(2, -1)
        log_std = log_std.clamp(self.LOG_STD_MIN, self.LOG_STD_MAX)
        return mu, log_std.exp()

    def _sample(self, s):
        mu, std = self._dist(s)
        n = torch.randn_like(mu)
        pre = mu + std * n
        a = torch.tanh(pre)
        logp = (-0.5 * (n ** 2) - std.log() -
                0.5 * np.log(2 * np.pi)).sum(-1)
        logp -= (2 * (np.log(2) - pre - F.softplus(-2 * pre))).sum(-1)
        return a, logp

    @torch.no_grad()
    def act(self, q, g, noise=None, deterministic=False):
        s = torch.as_tensor(np.concatenate([q, g])[None], dtype=torch.float32)
        if deterministic or noise == 0:
            mu, _ = self._dist(s)
            return torch.tanh(mu).numpy()[0]
        a, _ = self._sample(s)
        return a.numpy()[0]

    def update(self, buf, batch=128, **_):
        s, a, r, s2, done = buf.sample(batch)
        with torch.no_grad():
            a2, logp2 = self._sample(s2)
            qt = torch.min(self.q1_t(torch.cat([s2, a2], 1)),
                           self.q2_t(torch.cat([s2, a2], 1))).squeeze(-1)
            y = r + self.gamma * (1 - done) * (qt - self.alpha * logp2)
        sa = torch.cat([s, a], 1)
        lc = F.mse_loss(self.q1(sa).squeeze(-1), y) + \
            F.mse_loss(self.q2(sa).squeeze(-1), y)
        self.opt_c.zero_grad(); lc.backward(); self.opt_c.step()
        an, logp = self._sample(s)
        qn = torch.min(self.q1(torch.cat([s, an], 1)),
                       self.q2(torch.cat([s, an], 1))).squeeze(-1)
        lpi = (self.alpha * logp - qn).mean()
        self.opt_pi.zero_grad(); lpi.backward(); self.opt_pi.step()
        with torch.no_grad():
            for t, src in ((self.q1_t, self.q1), (self.q2_t, self.q2)):
                for pt, ps in zip(t.parameters(), src.parameters()):
                    pt.mul_(1 - self.tau).add_(self.tau * ps)
