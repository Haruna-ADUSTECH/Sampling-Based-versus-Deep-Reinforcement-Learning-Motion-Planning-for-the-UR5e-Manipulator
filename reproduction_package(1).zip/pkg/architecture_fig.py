"""Render the benchmark's software architecture as a block/flow diagram.
Colors intentionally match the PRM+SC (red) / SAC+HER (green) legend used
in fig_scenes.pdf, so the branch coloring reads consistently across the
paper's figures."""
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch
from matplotlib.colors import to_rgba

plt.rcParams.update({"font.size": 8})

SHARED = to_rgba("0.85")
SHARED_EDGE = "0.25"
SAMP = to_rgba("tab:red", 0.22)
SAMP_EDGE = "tab:red"
LEARN = to_rgba("tab:green", 0.22)
LEARN_EDGE = "tab:green"

fig, ax = plt.subplots(figsize=(3.4, 4.7))
ax.set_xlim(0, 1)
ax.set_ylim(0, 1)
ax.axis("off")


def box(x0, y0, w, h, text, face, edge, fontsize=7.2, weight="normal"):
    b = FancyBboxPatch((x0, y0), w, h,
                        boxstyle="round,pad=0.006,rounding_size=0.012",
                        linewidth=1.1, edgecolor=edge, facecolor=face,
                        mutation_aspect=1)
    ax.add_patch(b)
    ax.text(x0 + w / 2, y0 + h / 2, text, ha="center", va="center",
            fontsize=fontsize, linespacing=1.35)
    return x0, y0, w, h


def arrow(p1, p2, **kw):
    a = FancyArrowPatch(p1, p2, arrowstyle="-|>", mutation_scale=9,
                        linewidth=1.0, color="0.2", **kw)
    ax.add_patch(a)


# stage 1: scene & robot model
b1 = box(0.05, 0.875, 0.90, 0.105,
         "Scene and Robot Model\nUR5e 3-DOF capsule kinematics\nS1--S3 bar-obstacle layouts",
         SHARED, SHARED_EDGE)
# stage 2: collision checker
b2 = box(0.05, 0.715, 0.90, 0.105,
         "Collision Checker (shared)\n" r"$\mathcal{Q}_{free}$ / $\mathcal{Q}_{collide}$" "\nexact capsule segment distance",
         SHARED, SHARED_EDGE)
arrow((0.5, 0.875), (0.5, 0.820))

# stage 3: planning layer, two branches
b3a = box(0.05, 0.510, 0.415, 0.150,
          "Sampling-Based\nPRM, PRM+SC,\nRRT-Connect\n(queried online)",
          SAMP, SAMP_EDGE)
b3b = box(0.535, 0.510, 0.415, 0.150,
          "Learned (offline-trained)\nTD3+HER, SAC+HER\n(frozen actor, online rollout)",
          LEARN, LEARN_EDGE)
arrow((0.5, 0.715), (0.5, 0.690))
ax.text(0.5, 0.700, "Planning Layer", ha="center", va="bottom",
        fontsize=6.6, style="italic", color="0.25")
arrow((0.5, 0.690), (0.264, 0.663))
arrow((0.5, 0.690), (0.736, 0.663))

# stage 4: path / rollout
b4 = box(0.05, 0.390, 0.90, 0.095,
         "Path / Rollout\n(150 frozen queries $\\times$ 5 planners per scene)",
         SHARED, SHARED_EDGE)
arrow((0.264, 0.510), (0.44, 0.487))
arrow((0.736, 0.510), (0.56, 0.487))

# stage 5: evaluation module
b5 = box(0.05, 0.230, 0.90, 0.105,
         "Evaluation Module\nsuccess, $L$, $R$, $t_{plan}$, $t_{exec}$\n(Sec. IV-B metric definitions)",
         SHARED, SHARED_EDGE)
arrow((0.5, 0.390), (0.5, 0.335))

# stage 6: statistical testing
b6 = box(0.05, 0.045, 0.90, 0.13,
         "Statistical Testing\npaired Wilcoxon signed-rank\nvs. PRM+SC baseline\n(Sec. V-C, Sec. VI results)",
         SHARED, SHARED_EDGE)
arrow((0.5, 0.230), (0.5, 0.175))

fig.tight_layout(pad=0.15)
fig.savefig("fig_architecture.pdf", bbox_inches="tight")
print("fig_architecture.pdf written")
