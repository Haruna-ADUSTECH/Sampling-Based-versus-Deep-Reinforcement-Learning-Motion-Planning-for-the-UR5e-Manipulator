"""UR5e 3-DOF positioning-subspace environment with capsule collision model.

Kinematics: first three joints of the UR5e (DH parameters from Terreros et
al., ICCRE 2024: d1=0.163, a2=-0.425, a3=-0.39225, alpha1=pi/2); the wrist
is locked, so the collision-relevant geometry is the shoulder column, upper
arm and forearm, each modelled as a capsule. Obstacles are vertical capsule
"bars". This mirrors the 3-DOF settings of Kim et al. (2020) and the
capsule/GJK representation of Secil & Ozkan (2023).
"""
import numpy as np

D1, A2, A3 = 0.163, -0.425, -0.39225
R_LINK, R_BAR, R_COL = 0.05, 0.05, 0.07
Z_GROUND = 0.055
QLIM = np.array([[-2.6, 2.6], [-3.05, -0.10], [-2.70, 2.70]])


def fk_points(Q):
    """Q: (N,3) joint angles -> p1,p2,p3 each (N,3) world points
    (shoulder, elbow, wrist centre)."""
    Q = np.atleast_2d(Q)
    c1, s1 = np.cos(Q[:, 0]), np.sin(Q[:, 0])
    c2, s2 = np.cos(Q[:, 1]), np.sin(Q[:, 1])
    c23 = np.cos(Q[:, 1] + Q[:, 2])
    s23 = np.sin(Q[:, 1] + Q[:, 2])
    p1 = np.stack([np.zeros_like(c1), np.zeros_like(c1),
                   np.full_like(c1, D1)], 1)
    p2 = p1 + np.stack([A2 * c2 * c1, A2 * c2 * s1, A2 * s2], 1)
    p3 = p2 + np.stack([A3 * c23 * c1, A3 * c23 * s1, A3 * s23], 1)
    return p1, p2, p3


def _segseg(P1, P2, Q1, Q2):
    """Min distance between segments P1P2 and Q1Q2 (broadcastable, last
    dim 3). Ericson, Real-Time Collision Detection, Sec. 5.1.9."""
    d1 = P2 - P1
    d2 = Q2 - Q1
    r = P1 - Q1
    a = np.sum(d1 * d1, -1)
    e = np.sum(d2 * d2, -1)
    f = np.sum(d2 * r, -1)
    c = np.sum(d1 * r, -1)
    b = np.sum(d1 * d2, -1)
    den = a * e - b * b
    s = np.where(den > 1e-12, (b * f - c * e) / np.maximum(den, 1e-12), 0.0)
    s = np.clip(s, 0.0, 1.0)
    t = np.where(e > 1e-12, (b * s + f) / np.maximum(e, 1e-12), 0.0)
    t_cl = np.clip(t, 0.0, 1.0)
    s = np.where(e > 1e-12,
                 np.clip(np.where(np.abs(t - t_cl) > 0,
                                  (t_cl * b - c) / np.maximum(a, 1e-12), s),
                         0.0, 1.0), s)
    cp1 = P1 + s[..., None] * d1
    cp2 = Q1 + t_cl[..., None] * d2
    return np.linalg.norm(cp1 - cp2, axis=-1)


class Scene:
    def __init__(self, bars):
        """bars: list of (x, y) bar positions; vertical capsules z 0..0.9."""
        self.bars = np.array(bars, float).reshape(-1, 2)
        m = len(self.bars)
        self.b_lo = np.concatenate([self.bars, np.zeros((m, 1))], 1)
        self.b_hi = np.concatenate([self.bars, np.full((m, 1), 0.9)], 1)

    def in_collision(self, Q):
        """Q: (N,3) -> bool (N,). True where colliding / out of limits."""
        Q = np.atleast_2d(Q)
        bad = ((Q < QLIM[:, 0]) | (Q > QLIM[:, 1])).any(1)
        p1, p2, p3 = fk_points(Q)
        # ground (elbow / wrist below table)
        bad |= (p2[:, 2] < Z_GROUND) | (p3[:, 2] < Z_GROUND)
        # forearm vs shoulder column
        col_lo = np.array([0.0, 0.0, 0.0])
        col_hi = np.array([0.0, 0.0, D1])
        bad |= _segseg(p2, p3, col_lo, col_hi) < (R_LINK + R_COL)
        # both moving links vs each bar
        if len(self.bars):
            P1 = np.stack([p1, p2], 1)[:, :, None, :]   # (N,2,1,3)
            P2 = np.stack([p2, p3], 1)[:, :, None, :]
            Q1 = self.b_lo[None, None, :, :]            # (1,1,M,3)
            Q2 = self.b_hi[None, None, :, :]
            d = _segseg(P1, P2, Q1, Q2)                 # (N,2,M)
            bad |= (d < (R_LINK + R_BAR)).any(axis=(1, 2))
        return bad

    def edge_free(self, qa, qb, step=0.06):
        n = max(2, int(np.ceil(np.linalg.norm(qb - qa) / step)) + 1)
        Q = qa[None] + np.linspace(0, 1, n)[:, None] * (qb - qa)[None]
        return not self.in_collision(Q).any()

    def sample_free(self, rng, n=1):
        out = []
        while len(out) < n:
            Q = rng.uniform(QLIM[:, 0], QLIM[:, 1], size=(4 * n, 3))
            out.extend(Q[~self.in_collision(Q)])
        return np.array(out[:n])


SCENES = {
    "s1": Scene([(0.45, 0.10)]),
    "s2": Scene([(0.42, -0.30), (0.42, 0.30)]),
    "s3": Scene([(0.30, -0.38), (0.50, 0.00), (0.30, 0.38)]),
}


class RAMDP:
    """Goal-conditioned MDP of Kim et al. (2020) / Prianto et al. (2020):
    state q||g, action = bounded joint increment, reward -1 until
    ||q-g|| <= TOL, invalid steps clamp to the current state."""
    ALPHA = 0.25
    TOL = 0.15
    T = 50

    def __init__(self, scene, seed=0):
        self.scene = scene
        self.rng = np.random.default_rng(seed)

    def reset(self, q0=None, g=None):
        if q0 is None:
            while True:
                q0, g = self.scene.sample_free(self.rng, 2)
                if np.linalg.norm(q0 - g) > 1.0:
                    break
        self.q, self.g, self.t = q0.copy(), g.copy(), 0
        return self.q.copy(), self.g.copy()

    def step(self, a):
        a = np.clip(a, -1, 1)
        q_hat = self.q + self.ALPHA * a
        if not self.scene.in_collision(q_hat[None])[0]:
            self.q = q_hat
        self.t += 1
        done_goal = np.linalg.norm(self.q - self.g) <= self.TOL
        r = 0.0 if done_goal else -1.0
        done = done_goal or self.t >= self.T
        return self.q.copy(), r, done, done_goal
